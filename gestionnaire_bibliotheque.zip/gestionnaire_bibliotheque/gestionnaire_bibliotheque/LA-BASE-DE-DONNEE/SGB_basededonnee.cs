﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace gestionnaire_bibliotheque.LA_BASE_DE_DONNEE
{
    class SGB_basededonnee
    {
        // la connexion à la base de donnée
       private MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=sgb_basededonnee;");

        //création de la fonction d'ouverture de la connexion
        public void openConnection()
        {
            if(connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        //création de la fonction de fermeture de la connexion
        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }

        // création d'une fonction de retour de connection
        public MySqlConnection GetConnection()

        {
            return connection;
        }

        //création d'une fonction de retour vers la table de data
        // parameters = parametres de la requête(query)
        public DataTable GetData(string query, MySqlParameter[] parameters)
        {
            MySqlCommand command = new MySqlCommand(query, connection);
            if(parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(table);
            return table;
        }

        //création d'une fonction pour définir des données et exécuter une requête
        public int setData(string query, MySqlParameter[] parameters)
        {
            MySqlCommand command = new MySqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }

            openConnection();

            int commandState = command.ExecuteNonQuery();

            closeConnection();

            return commandState;
        }
    }
}
