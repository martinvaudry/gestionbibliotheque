﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class gestion_auteurs_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.texte_biographie = new System.Windows.Forms.RichTextBox();
            this.dataGridView_auteurs = new System.Windows.Forms.DataGridView();
            this.label_biographie = new System.Windows.Forms.Label();
            this.texte_education = new System.Windows.Forms.TextBox();
            this.label_education = new System.Windows.Forms.Label();
            this.texte_nom = new System.Windows.Forms.TextBox();
            this.label_nom = new System.Windows.Forms.Label();
            this.texte_prenom = new System.Windows.Forms.TextBox();
            this.texte_id = new System.Windows.Forms.TextBox();
            this.label_prenom = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bouton_liste_livres_auteur = new System.Windows.Forms.Button();
            this.label_compteur_auteurs = new System.Windows.Forms.Label();
            this.bouton_exporter_livres = new System.Windows.Forms.Button();
            this.bouton_supprimer = new System.Windows.Forms.Button();
            this.bouton_modifier = new System.Windows.Forms.Button();
            this.bouton_ajouter = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.gestion_auteurs = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_auteurs)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1411, 634);
            this.panel1.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightBlue;
            this.panel4.Controls.Add(this.texte_biographie);
            this.panel4.Controls.Add(this.dataGridView_auteurs);
            this.panel4.Controls.Add(this.label_biographie);
            this.panel4.Controls.Add(this.texte_education);
            this.panel4.Controls.Add(this.label_education);
            this.panel4.Controls.Add(this.texte_nom);
            this.panel4.Controls.Add(this.label_nom);
            this.panel4.Controls.Add(this.texte_prenom);
            this.panel4.Controls.Add(this.texte_id);
            this.panel4.Controls.Add(this.label_prenom);
            this.panel4.Controls.Add(this.label_id);
            this.panel4.Location = new System.Drawing.Point(250, 177);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1152, 434);
            this.panel4.TabIndex = 6;
            // 
            // texte_biographie
            // 
            this.texte_biographie.Location = new System.Drawing.Point(160, 239);
            this.texte_biographie.Name = "texte_biographie";
            this.texte_biographie.Size = new System.Drawing.Size(355, 170);
            this.texte_biographie.TabIndex = 15;
            this.texte_biographie.Text = "";
            // 
            // dataGridView_auteurs
            // 
            this.dataGridView_auteurs.AllowUserToAddRows = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_auteurs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_auteurs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_auteurs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_auteurs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_auteurs.Location = new System.Drawing.Point(537, 23);
            this.dataGridView_auteurs.Name = "dataGridView_auteurs";
            this.dataGridView_auteurs.Size = new System.Drawing.Size(601, 386);
            this.dataGridView_auteurs.TabIndex = 14;
            this.dataGridView_auteurs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_auteurs_CellClick);
            // 
            // label_biographie
            // 
            this.label_biographie.AutoSize = true;
            this.label_biographie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_biographie.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_biographie.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_biographie.Location = new System.Drawing.Point(18, 239);
            this.label_biographie.Name = "label_biographie";
            this.label_biographie.Size = new System.Drawing.Size(129, 24);
            this.label_biographie.TabIndex = 12;
            this.label_biographie.Text = "Biographie:";
            // 
            // texte_education
            // 
            this.texte_education.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_education.Location = new System.Drawing.Point(160, 181);
            this.texte_education.Name = "texte_education";
            this.texte_education.Size = new System.Drawing.Size(355, 32);
            this.texte_education.TabIndex = 11;
            // 
            // label_education
            // 
            this.label_education.AutoSize = true;
            this.label_education.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_education.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_education.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_education.Location = new System.Drawing.Point(27, 183);
            this.label_education.Name = "label_education";
            this.label_education.Size = new System.Drawing.Size(120, 24);
            this.label_education.TabIndex = 10;
            this.label_education.Text = "Éducation:";
            // 
            // texte_nom
            // 
            this.texte_nom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_nom.Location = new System.Drawing.Point(160, 127);
            this.texte_nom.Name = "texte_nom";
            this.texte_nom.Size = new System.Drawing.Size(355, 32);
            this.texte_nom.TabIndex = 9;
            // 
            // label_nom
            // 
            this.label_nom.AutoSize = true;
            this.label_nom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_nom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nom.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_nom.Location = new System.Drawing.Point(82, 129);
            this.label_nom.Name = "label_nom";
            this.label_nom.Size = new System.Drawing.Size(65, 24);
            this.label_nom.TabIndex = 8;
            this.label_nom.Text = "Nom:";
            // 
            // texte_prenom
            // 
            this.texte_prenom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_prenom.Location = new System.Drawing.Point(160, 76);
            this.texte_prenom.Name = "texte_prenom";
            this.texte_prenom.Size = new System.Drawing.Size(355, 32);
            this.texte_prenom.TabIndex = 7;
            // 
            // texte_id
            // 
            this.texte_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_id.Location = new System.Drawing.Point(160, 23);
            this.texte_id.Name = "texte_id";
            this.texte_id.Size = new System.Drawing.Size(176, 32);
            this.texte_id.TabIndex = 6;
            // 
            // label_prenom
            // 
            this.label_prenom.AutoSize = true;
            this.label_prenom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_prenom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_prenom.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_prenom.Location = new System.Drawing.Point(50, 78);
            this.label_prenom.Name = "label_prenom";
            this.label_prenom.Size = new System.Drawing.Size(97, 24);
            this.label_prenom.TabIndex = 5;
            this.label_prenom.Text = "Prénom:";
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_id.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_id.Location = new System.Drawing.Point(107, 26);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(40, 24);
            this.label_id.TabIndex = 4;
            this.label_id.Text = "ID:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.bouton_liste_livres_auteur);
            this.panel3.Controls.Add(this.label_compteur_auteurs);
            this.panel3.Controls.Add(this.bouton_exporter_livres);
            this.panel3.Controls.Add(this.bouton_supprimer);
            this.panel3.Controls.Add(this.bouton_modifier);
            this.panel3.Controls.Add(this.bouton_ajouter);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 165);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(237, 469);
            this.panel3.TabIndex = 5;
            // 
            // bouton_liste_livres_auteur
            // 
            this.bouton_liste_livres_auteur.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.bouton_liste_livres_auteur.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_liste_livres_auteur.FlatAppearance.BorderSize = 2;
            this.bouton_liste_livres_auteur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_liste_livres_auteur.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_liste_livres_auteur.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_liste_livres_auteur.Location = new System.Drawing.Point(12, 265);
            this.bouton_liste_livres_auteur.Name = "bouton_liste_livres_auteur";
            this.bouton_liste_livres_auteur.Size = new System.Drawing.Size(210, 75);
            this.bouton_liste_livres_auteur.TabIndex = 46;
            this.bouton_liste_livres_auteur.Text = "Voir l\'oeuvre entier d\'un auteur";
            this.bouton_liste_livres_auteur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_liste_livres_auteur.UseVisualStyleBackColor = false;
            this.bouton_liste_livres_auteur.Click += new System.EventHandler(this.bouton_liste_livres_auteur_Click);
            // 
            // label_compteur_auteurs
            // 
            this.label_compteur_auteurs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_compteur_auteurs.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_compteur_auteurs.ForeColor = System.Drawing.Color.LightBlue;
            this.label_compteur_auteurs.Location = new System.Drawing.Point(13, 427);
            this.label_compteur_auteurs.Name = "label_compteur_auteurs";
            this.label_compteur_auteurs.Size = new System.Drawing.Size(209, 24);
            this.label_compteur_auteurs.TabIndex = 45;
            this.label_compteur_auteurs.Text = "9999 auteurs";
            this.label_compteur_auteurs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bouton_exporter_livres
            // 
            this.bouton_exporter_livres.BackColor = System.Drawing.Color.Plum;
            this.bouton_exporter_livres.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_exporter_livres.FlatAppearance.BorderSize = 2;
            this.bouton_exporter_livres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_exporter_livres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_exporter_livres.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_exporter_livres.Location = new System.Drawing.Point(12, 346);
            this.bouton_exporter_livres.Name = "bouton_exporter_livres";
            this.bouton_exporter_livres.Size = new System.Drawing.Size(210, 75);
            this.bouton_exporter_livres.TabIndex = 9;
            this.bouton_exporter_livres.Text = "Exporter vers fichier texte";
            this.bouton_exporter_livres.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_exporter_livres.UseVisualStyleBackColor = false;
            this.bouton_exporter_livres.Click += new System.EventHandler(this.bouton_voir_oeuvre_auteur_Click);
            // 
            // bouton_supprimer
            // 
            this.bouton_supprimer.BackColor = System.Drawing.Color.LightPink;
            this.bouton_supprimer.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.FlatAppearance.BorderSize = 2;
            this.bouton_supprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_supprimer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_supprimer.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.Location = new System.Drawing.Point(12, 184);
            this.bouton_supprimer.Name = "bouton_supprimer";
            this.bouton_supprimer.Size = new System.Drawing.Size(210, 75);
            this.bouton_supprimer.TabIndex = 8;
            this.bouton_supprimer.Text = " Supprimer";
            this.bouton_supprimer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_supprimer.UseVisualStyleBackColor = false;
            this.bouton_supprimer.Click += new System.EventHandler(this.bouton_supprimer_Click);
            // 
            // bouton_modifier
            // 
            this.bouton_modifier.BackColor = System.Drawing.Color.PaleGreen;
            this.bouton_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.FlatAppearance.BorderSize = 2;
            this.bouton_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_modifier.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.Location = new System.Drawing.Point(12, 103);
            this.bouton_modifier.Name = "bouton_modifier";
            this.bouton_modifier.Size = new System.Drawing.Size(210, 75);
            this.bouton_modifier.TabIndex = 7;
            this.bouton_modifier.Text = "Modifier";
            this.bouton_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_modifier.UseVisualStyleBackColor = false;
            this.bouton_modifier.Click += new System.EventHandler(this.bouton_modifier_Click);
            // 
            // bouton_ajouter
            // 
            this.bouton_ajouter.BackColor = System.Drawing.Color.LightBlue;
            this.bouton_ajouter.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.FlatAppearance.BorderSize = 2;
            this.bouton_ajouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_ajouter.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_ajouter.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.Location = new System.Drawing.Point(12, 22);
            this.bouton_ajouter.Name = "bouton_ajouter";
            this.bouton_ajouter.Size = new System.Drawing.Size(210, 75);
            this.bouton_ajouter.TabIndex = 6;
            this.bouton_ajouter.Text = "  Ajouter";
            this.bouton_ajouter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_ajouter.UseVisualStyleBackColor = false;
            this.bouton_ajouter.Click += new System.EventHandler(this.bouton_ajouter_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Label_fermeture);
            this.panel2.Controls.Add(this.gestion_auteurs);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1411, 165);
            this.panel2.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightBlue;
            this.pictureBox1.ImageLocation = "../../IMAGES/auteurs_ico.png";
            this.pictureBox1.Location = new System.Drawing.Point(29, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 158);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(1327, 9);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 3;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // gestion_auteurs
            // 
            this.gestion_auteurs.BackColor = System.Drawing.Color.LightBlue;
            this.gestion_auteurs.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gestion_auteurs.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gestion_auteurs.Location = new System.Drawing.Point(235, 0);
            this.gestion_auteurs.Name = "gestion_auteurs";
            this.gestion_auteurs.Size = new System.Drawing.Size(1176, 165);
            this.gestion_auteurs.TabIndex = 1;
            this.gestion_auteurs.Text = "Gestion des auteurs";
            this.gestion_auteurs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gestion_auteurs_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1411, 634);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "gestion_auteurs_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "gestion_auteurs_formulaire";
            this.Load += new System.EventHandler(this.gestion_auteurs_formulaire_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_auteurs)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Label gestion_auteurs;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bouton_supprimer;
        private System.Windows.Forms.Button bouton_modifier;
        private System.Windows.Forms.Button bouton_ajouter;
        private System.Windows.Forms.TextBox texte_education;
        private System.Windows.Forms.Label label_education;
        private System.Windows.Forms.TextBox texte_nom;
        private System.Windows.Forms.Label label_nom;
        private System.Windows.Forms.TextBox texte_prenom;
        private System.Windows.Forms.TextBox texte_id;
        private System.Windows.Forms.Label label_prenom;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.DataGridView dataGridView_auteurs;
        private System.Windows.Forms.Button bouton_exporter_livres;
        private System.Windows.Forms.Label label_compteur_auteurs;
        private System.Windows.Forms.RichTextBox texte_biographie;
        private System.Windows.Forms.Label label_biographie;
        private System.Windows.Forms.Button bouton_liste_livres_auteur;
    }
}