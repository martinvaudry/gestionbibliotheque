﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class gestion_livres_formulaire : Form
    {
        public gestion_livres_formulaire()
        {
            InitializeComponent();
        }

        CLASSES.LIVRES livre = new CLASSES.LIVRES();
        CLASSES.GENRES genre = new CLASSES.GENRES();
        CLASSES.AUTEUR auteur = new CLASSES.AUTEUR();

        //Fermer la fenêtre gestion des livres
        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Montrer les images des bouton/tableaux des auteurs/modification de la grille
        private void gestion_livres_formulaire_Load(object sender, EventArgs e)
        {
            //Images boutons
            bouton_ajouter.Image = Image.FromFile("../../IMAGES/plus.png");
            bouton_modifier.Image = Image.FromFile("../../IMAGES/updates.png");
            bouton_supprimer.Image = Image.FromFile("../../IMAGES/delete.png");
            button_teledeposer_modifier.Image = Image.FromFile("../../IMAGES/telecharge.png");
            bouton_teledeposer.Image = Image.FromFile("../../IMAGES/telecharge.png");
            bouton_liste_de_livres.Image = Image.FromFile("../../IMAGES/liste_livres.png");

            //Fournir la boite avec les genres (dans modifier)
            
            comboBox_genre_modifer.DataSource = genre.listegenres();
            comboBox_genre_modifer.DisplayMember = "nom";
            comboBox_genre_modifer.ValueMember = "id";

            //placer l'ID  dans le textbox_id à l'affichage du formulaire
            int nombre_livres = livre.listelivres().Rows.Count + 1;
            texte_id.Text = nombre_livres.ToString();
            //afficher le compteur de livres
            label_compteur_livres.Text = livre.listelivres().Rows.Count.ToString() + " Livres";

            //montrer le panel modifier par défaut (à l'affichage du formulaire)
            panel_modifier.BringToFront();
        }

        // --------------------------------------------------------------------------------------------------------
        //             PANEL  AJOUTER
        // --------------------------------------------------------------------------------------------------------

        //Chercher et placer une image pour la pochette
        private void bouton_teledeposer_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            //types d'image
            opf.Filter = "Choisissez une image(*.jpg;*.png;*.gif)| *.jpg;*.png;*.gif";

            if(opf.ShowDialog() == DialogResult.OK)
            {
                //Placer l'image dans la boite_image
                pictureBox_pochette.Image = Image.FromFile(opf.FileName);
            }
        }

        //Montrer la liste des auteurs dans une nouvelle fenêtre
        private void bouton_selection_auteur_Click(object sender, EventArgs e)
        {
           
            liste_auteurs_formulaire liste = new liste_auteurs_formulaire(this);
            liste.Show();
        }

        
        //Bouton ajouter le livre dans la base de donnée
        private void bouton_ajoutlivre_Click(object sender, EventArgs e)
        {
            int genre_id;
            int auteur_id;
            int quantite;
            int pages;
            double prix;
            string isbn = texte_isbn.Text;
            string titre = texte_titre.Text;
            string publie = texte_publie.Text;
            string description = texte_description.Text;
            DateTime date_recu = dateTimePicker_recu.Value;

            MemoryStream ms = new MemoryStream();
            pictureBox_pochette.Image.Save(ms, pictureBox_pochette.Image.RawFormat);
            byte[] pochette = ms.ToArray();

            try
            {
                genre_id = Convert.ToInt32(texte_genre.SelectedValue);
                auteur_id = Convert.ToInt32(label_auteur_id.Text);
                quantite = Convert.ToInt32(numericUpDown_quantite.Value);
                pages = Convert.ToInt32(numericUpDown_pages.Value);
                prix = Convert.ToDouble(texte_prix.Text);

                //le livre doit être unique
                //vérification que le ISBN soit unique
               if (!livre.IsisbnExists(isbn, 0))
                {
                    //vérifier si le titre est unique
                    if (!livre.TitreExists(titre, 0))
                    {
                        if (livre.ajouterlivre(isbn, titre, genre_id, auteur_id, quantite, pages, prix, publie, date_recu, description, pochette))
                        {
                            MessageBox.Show("Nouveau livre ajouté avec succès", "Nouveau livre ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            //Mise à jour du compteur de livres
                            label_compteur_livres.Text = livre.listelivres().Rows.Count.ToString() + " Livres";
                        }
                        else
                        {
                            MessageBox.Show("Pas de nouveau livre ajouté", "Nouveau livre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Le titre inscrit existe déjà! Chaque livre en a un unique. Pouvez-vous le changer?", "Titre en double", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
                else
                {
                    MessageBox.Show("L'ISBN inscrit existe déjà! Chaque livre en a un unique. Pouvez-vous le changer?", "ISBN en double", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Effacer tous les champs dans la fenêtre gestion des livres
        private void bouton_efface_champs_Click(object sender, EventArgs e)
        {
            //utilisation d'un foreach loop pour effacer tous les champs
            foreach(var control in panel_ajouter.Controls)
            {
                if(control.GetType() == typeof(TextBox))
                {
                    TextBox tb = (TextBox)control;
                    tb.Text = "";
                }
            }
            //placer l'ID  dans le textbox_id (allant chercher le dernier dans le database)
            int nombre_livres = livre.listelivres().Rows.Count;
            int dernierlivreId = 1;
            if (nombre_livres > 0)
            {
                dernierlivreId = Convert.ToInt32(livre.listelivres().Rows[nombre_livres - 1][0].ToString()) + 1;
            }
      
            texte_id.Text = Convert.ToString(dernierlivreId);


            texte_description.Text = "";
            label_auteur_id.Text = "ID";
            texte_genre.SelectedIndex = 0;
            numericUpDown_pages.Value = 0;
            numericUpDown_quantite.Value = 0;
            texte_prix.Text = "0";
            dateTimePicker_recu.Value = DateTime.Now;
            pictureBox_pochette.ImageLocation = "../../IMAGES/pochette_template.png";
        }

        //----------------------------------------------------------------------------------------------------------------
        //          PANEL SWITCH  //
        //----------------------------------------------------------------------------------------------------------------


        // pour montrer le panel d'ajout de livre
        private void bouton_ajouter_Click(object sender, EventArgs e)
        {
            panel_ajouter.BringToFront();
            //Fournir la boite avec les genres (dans ajouter)
            texte_genre.DataSource = genre.listegenres();
            texte_genre.DisplayMember = "nom";
            texte_genre.ValueMember = "id";
            //Nettoyer les champs auteur et id
            texte_auteur_nomcomplet.Text = "";
            label_auteur_id.Text = "ID";
        }
        // pour montrer le panel modifier le livre
        private void bouton_modifier_Click(object sender, EventArgs e)
        {
            panel_modifier.BringToFront();
            //Fournir la boite avec les genres (dans modifier)
            comboBox_genre_modifer.DataSource = genre.listegenres();
            comboBox_genre_modifer.DisplayMember = "nom";
            comboBox_genre_modifer.ValueMember = "id";

            //Nettoyer les champs auteur et id
            textBox_auteur_modifier.Text = "";
            label_auteur_id_modifier.Text = "ID";
        }


        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        //          PANEL MODIFICATION ************************************************************************************************************************************
        //-----------------------------------------------------------------------------------------------------------------------------------------------------------------

        //bouton pour télédéposer la pochette dans panel modifier
        private void button_teledeposer_modifier_Click(object sender, EventArgs e)
        {

            // j'aurais pu simplement appeler le bouton  original avec un performclick dessus = bouton_teledeposer.PerformClick();

            OpenFileDialog opf = new OpenFileDialog();
            //types d'image
            opf.Filter = "Choisissez une image(*.jpg;*.png;*.gif)| *.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                //Placer l'image dans la boite_image
                pictureBox_pochette_modifier.Image = Image.FromFile(opf.FileName);
            }
        }

        //Chercher un livre par le # ID
        private void button_cherche_id_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBox_id_modifier.Text);
            DataTable data = livre.cherche_LivrePar_IDouISBN("id", id, "");
            if (data.Rows.Count > 0)
            {
                displayData(data);
            }
            else
            {
                MessageBox.Show("L'ID inscrit n'existe pas! Faites un autre choix", "ID inexistant!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        //Chercher un livre par le # ISBN
        private void button_cherche_isbn_Click(object sender, EventArgs e)
        {
            string isbn = textBox_isbn_modifier.Text;
            DataTable data = livre.cherche_LivrePar_IDouISBN("isbn", 00, isbn);
            if (data.Rows.Count > 0)
            {
                displayData(data);
            }
            else
            {
                MessageBox.Show("L'ISBN inscrit n'existe pas! Faites un autre choix", "ISBN inexistant!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        //Montrer la liste des auteurs dans une nouvelle fenêtre pour en modifier le nom 
        private void bouton_selection_auteur_modifier_Click(object sender, EventArgs e)
        {
            
            liste_auteurs_formulaire liste = new liste_auteurs_formulaire(this);
            liste.Show();
        }

        // bouton enregistrer les modifications
        private void enregistrer_modifications_Click(object sender, EventArgs e)
        {
            int id;
            int genre_id;
            int auteur_id;
            int quantite;
            int pages;
            double prix;
            //string auteur = textBox_auteur_modifier.Text;
            string isbn = textBox_id_modifier.Text;
            string titre = textBox_titre_modifier.Text;
            string publie = textBox_publie_modifier.Text;
            string description = richTextBox_description_modifier.Text;
            DateTime date_recu = dateTimePicker_date_recu_modifier.Value;

            MemoryStream ms = new MemoryStream();
            pictureBox_pochette_modifier.Image.Save(ms, pictureBox_pochette_modifier.Image.RawFormat);
            byte[] pochette = ms.ToArray();

            try
            {
                id = Convert.ToInt32(textBox_id_modifier.Text);
                genre_id = Convert.ToInt32(comboBox_genre_modifer.SelectedValue);
                auteur_id = Convert.ToInt32(label_auteur_id_modifier.Text);
                quantite = Convert.ToInt32(numericUpDown_quantite_modifier.Value);
                pages = Convert.ToInt32(numericUpDown_pages_modifier.Value);
                prix = Convert.ToDouble(textBox_prix_modifier.Text);

                //le livre doit être unique
                //vérification que le ISBN soit unique
                if (!livre.IsisbnExists(isbn, id))
                {
                    //vérifier si le titre est unique
                    if (!livre.TitreExists(titre, id))
                    {
                        if (livre.modifierlivre(id, isbn, titre, genre_id, auteur_id, quantite, pages, prix, publie, date_recu, description, pochette))
                        {
                            MessageBox.Show("Le livre a été modifier avec succès", "Modification du livre ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            //Mise à jour du compteur de livres
                            label_compteur_livres.Text = livre.listelivres().Rows.Count.ToString() + " Livres";
                        }
                        else
                        {
                            MessageBox.Show("Le livre n'a pas été modifier", "Modification livre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Le titre inscrit existe déjà! Chaque livre en a un unique. Pouvez-vous le changer?", "Titre en double", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
                else
                {
                    MessageBox.Show("L'ISBN inscrit existe déjà! Chaque livre en a un unique. Pouvez-vous le changer?", "ISBN en double", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //créer une fonction pour montrer le data dans les champs
        public void displayData(DataTable data)
        {
            textBox_id_modifier.Text = data.Rows[0][0].ToString();
            textBox_isbn_modifier.Text = data.Rows[0][1].ToString();
            textBox_titre_modifier.Text = data.Rows[0][2].ToString();
            comboBox_genre_modifer.SelectedValue = data.Rows[0][3].ToString();

            //recherche par id pousser le nom de l'auteur dans le textbox
            int auteur_id = Convert.ToInt32(data.Rows[0][4].ToString());
            DataTable auteurData = auteur.avoirAuteurparId(auteur_id);
            textBox_auteur_modifier.Text = auteurData.Rows[0][1].ToString() + " " + auteurData.Rows[0][2].ToString();

            label_auteur_id_modifier.Text = data.Rows[0][4].ToString();
            numericUpDown_pages_modifier.Text = data.Rows[0][5].ToString();
            numericUpDown_quantite_modifier.Text = data.Rows[0][6].ToString();
            textBox_prix_modifier.Text = data.Rows[0][7].ToString();
            textBox_publie_modifier.Text = data.Rows[0][8].ToString();
            dateTimePicker_date_recu_modifier.Value = (DateTime)data.Rows[0][9];
            richTextBox_description_modifier.Text = data.Rows[0][10].ToString();

            byte[] pochette = (byte[])data.Rows[0][11];
            MemoryStream ms = new MemoryStream(pochette);
            pictureBox_pochette_modifier.Image = Image.FromStream(ms);
        }
        //Supprmier le livre sélectionné
        private void bouton_supprimer_Click(object sender, EventArgs e)
        {
            // montrer la fenêtre de suppression de livre (le formulaire)
            livres_supprimes_formulaire suplivf = new livres_supprimes_formulaire();
            suplivf.Show();
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
        //          Panel voir liste des livres ************************************************************************************************************************
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------

        //Montrer la liste des livres
        private void bouton_liste_de_livres_Click(object sender, EventArgs e)
        {
            panel_montre_livres.BringToFront();

            //modifier les rangées  de datagridview la hauteur
            dataGridView_liste_livres.RowTemplate.Height = 100;

            //montrer la liste des livres dans la grille (datagridview)
            dataGridView_liste_livres.DataSource = livre.listelivres();

            //modifier les rangées  de datagridview la pochette
            DataGridViewImageColumn dgvImgCol = new DataGridViewImageColumn();
            dgvImgCol = (DataGridViewImageColumn)dataGridView_liste_livres.Columns[11];
            dgvImgCol.ImageLayout = DataGridViewImageCellLayout.Stretch;

            // Modifier la grille 
            dataGridView_liste_livres.ColumnHeadersDefaultCellStyle.ForeColor = Color.MidnightBlue;
            dataGridView_liste_livres.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 16, FontStyle.Bold);
            dataGridView_liste_livres.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridView_liste_livres.EnableHeadersVisualStyles = false;

            
        }
        // bouton - aller modifier le livre sélectionné dans la grille(datagridview)
        private void button_selection_modifier_Click(object sender, EventArgs e)
        {
            panel_modifier.BringToFront();
            //Fournir la boite avec les genres (dans modifier)
            comboBox_genre_modifer.DataSource = genre.listegenres();
            comboBox_genre_modifer.DisplayMember = "nom";
            comboBox_genre_modifer.ValueMember = "id";

            int id = Convert.ToInt32(dataGridView_liste_livres.CurrentRow.Cells[0].Value);
            DataTable data = livre.cherche_LivrePar_IDouISBN("id", id, "");
            if (data.Rows.Count > 0)
            {
                displayData(data);
            }
            else
            {
                MessageBox.Show("L'ID inscrit n'existe pas! Faites un autre choix", "ID inexistant!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }


        }
        // bouton - aller supprimer le livre sélectionné dans la grille(datagridview)
        private void button_selction_supprimer_livre_Click(object sender, EventArgs e)
            {
                 DialogResult result = MessageBox.Show("Voulez-vous vraiment supprimer ce livre?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                {
                    int index = this.dataGridView_liste_livres.CurrentRow.Index;
                    this.dataGridView_liste_livres.Rows.RemoveAt(index);
                    MessageBox.Show("Le livre a bien été supprimé", "Suppression du livre");
                }
                else
                {
                    MessageBox.Show("Le livre n'a pas été supprimer", "Suppression du livre ignoré");
                }
        }
    }
}