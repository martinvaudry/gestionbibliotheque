﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class Connexion_formlaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.bouton_connexion = new System.Windows.Forms.Button();
            this.texte_motdepasse = new System.Windows.Forms.TextBox();
            this.MotdePasse_Image = new System.Windows.Forms.PictureBox();
            this.texte_usager = new System.Windows.Forms.TextBox();
            this.NomUsager_Image = new System.Windows.Forms.PictureBox();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MotdePasse_Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NomUsager_Image)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.Controls.Add(this.bouton_connexion);
            this.panel1.Controls.Add(this.texte_motdepasse);
            this.panel1.Controls.Add(this.MotdePasse_Image);
            this.panel1.Controls.Add(this.texte_usager);
            this.panel1.Controls.Add(this.NomUsager_Image);
            this.panel1.Controls.Add(this.Label_fermeture);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(674, 469);
            this.panel1.TabIndex = 0;
            // 
            // bouton_connexion
            // 
            this.bouton_connexion.BackColor = System.Drawing.Color.LightBlue;
            this.bouton_connexion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_connexion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_connexion.Font = new System.Drawing.Font("Berlin Sans FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_connexion.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_connexion.Location = new System.Drawing.Point(80, 343);
            this.bouton_connexion.Name = "bouton_connexion";
            this.bouton_connexion.Size = new System.Drawing.Size(513, 45);
            this.bouton_connexion.TabIndex = 6;
            this.bouton_connexion.Text = "CONNEXION";
            this.bouton_connexion.UseVisualStyleBackColor = false;
            this.bouton_connexion.Click += new System.EventHandler(this.bouton_connexion_Click);
            // 
            // texte_motdepasse
            // 
            this.texte_motdepasse.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_motdepasse.Location = new System.Drawing.Point(203, 234);
            this.texte_motdepasse.Name = "texte_motdepasse";
            this.texte_motdepasse.Size = new System.Drawing.Size(390, 63);
            this.texte_motdepasse.TabIndex = 5;
            this.texte_motdepasse.UseSystemPasswordChar = true;
            // 
            // MotdePasse_Image
            // 
            this.MotdePasse_Image.BackColor = System.Drawing.Color.LightBlue;
            this.MotdePasse_Image.Location = new System.Drawing.Point(80, 227);
            this.MotdePasse_Image.Name = "MotdePasse_Image";
            this.MotdePasse_Image.Size = new System.Drawing.Size(90, 73);
            this.MotdePasse_Image.TabIndex = 4;
            this.MotdePasse_Image.TabStop = false;
            // 
            // texte_usager
            // 
            this.texte_usager.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_usager.Location = new System.Drawing.Point(203, 120);
            this.texte_usager.Name = "texte_usager";
            this.texte_usager.Size = new System.Drawing.Size(390, 63);
            this.texte_usager.TabIndex = 3;
            // 
            // NomUsager_Image
            // 
            this.NomUsager_Image.BackColor = System.Drawing.Color.LightBlue;
            this.NomUsager_Image.Location = new System.Drawing.Point(80, 114);
            this.NomUsager_Image.Name = "NomUsager_Image";
            this.NomUsager_Image.Size = new System.Drawing.Size(90, 73);
            this.NomUsager_Image.TabIndex = 2;
            this.NomUsager_Image.TabStop = false;
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(638, 3);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 1;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            this.Label_fermeture.MouseEnter += new System.EventHandler(this.Label_fermeture_MouseEnter);
            this.Label_fermeture.MouseLeave += new System.EventHandler(this.Label_fermeture_MouseLeave);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(672, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "Connexion de l\'usager";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Connexion_formlaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 469);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Connexion_formlaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Connexion_formlaire";
            this.Load += new System.EventHandler(this.Connexion_formlaire_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MotdePasse_Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NomUsager_Image)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bouton_connexion;
        private System.Windows.Forms.TextBox texte_motdepasse;
        private System.Windows.Forms.PictureBox MotdePasse_Image;
        private System.Windows.Forms.TextBox texte_usager;
        private System.Windows.Forms.PictureBox NomUsager_Image;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Label label1;
    }
}