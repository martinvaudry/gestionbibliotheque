﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class gestion_auteurs_formulaire : Form
    {
        CLASSES.AUTEUR auteur = new CLASSES.AUTEUR();

        public gestion_auteurs_formulaire()
        {
            InitializeComponent();
        }
        // Fermer la fenêtre gestion des auteurs
        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Montrer les images des bouton/tableaux des auteurs/modification de la grille
        private void gestion_auteurs_formulaire_Load(object sender, EventArgs e)
        {
            //Images boutons
            bouton_ajouter.Image = Image.FromFile("../../IMAGES/plus.png");
            bouton_modifier.Image = Image.FromFile("../../IMAGES/updates.png");
            bouton_supprimer.Image = Image.FromFile("../../IMAGES/delete.png");

            // montrer le tableau des auteurs
            dataGridView_auteurs.DataSource = auteur.listeauteurs(false);

            // Modifier la grille 
            dataGridView_auteurs.ColumnHeadersDefaultCellStyle.ForeColor = Color.MidnightBlue;
            dataGridView_auteurs.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 16, FontStyle.Bold);
            dataGridView_auteurs.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridView_auteurs.EnableHeadersVisualStyles = false;

            //afficher le compteur de auteurs
            label_compteur_auteurs.Text = auteur.listeauteurs(false).Rows.Count.ToString() + " auteurs";

            dataGridView_auteurs.EnableHeadersVisualStyles = false;
        }
        // Bouton pour ajouter un(e) auteur(e)
        private void bouton_ajouter_Click(object sender, EventArgs e)
        {
            string prenom = texte_prenom.Text;
            string nom = texte_nom.Text;
            string education = texte_education.Text;
            string biographie = texte_biographie.Text;

            // vérifie si le prénom/nom sont vide
            if (prenom.Trim().Equals("")|| nom.Trim().Equals(""))
                {
                MessageBox.Show("Vous devez entrer un prénom et un nom de famille pour l'auteur", "Data vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
             else
                {
                    if (auteur.ajouterauteur(prenom, nom, education, biographie))
                    {

                    MessageBox.Show("Nouvel(le) auteur(e) ajouté(e) avec succès", "Nouvel(le) auteur(e)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // mise à jour du tableau des genres
                    dataGridView_auteurs.DataSource = auteur.listeauteurs(false);

                    //mise à jour du compteur de auteurs
                    label_compteur_auteurs.Text = auteur.listeauteurs(false).Rows.Count.ToString() + " auteurs";

                    }
                    else
                    {
                    MessageBox.Show("Pas de nouvel(le) auteur(e) ajouté(e)", "Nouvel(le) auteur(e) en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
            
                 }
        }
        // Bouton de modification des auteurs
        private void bouton_modifier_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(texte_id.Text);
                string prenom = texte_prenom.Text;
                string nom = texte_nom.Text;
                string education = texte_education.Text;
                string biographie = texte_biographie.Text;

                // vérifie si le prénom/nom sont vide
                if (prenom.Trim().Equals("") || nom.Trim().Equals(""))
                {
                    MessageBox.Show("Vous devez entrer un prénom et un nom de famille pour l'auteur", "Data vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (auteur.modifierauteur(id, prenom, nom, education, biographie))
                    {

                        MessageBox.Show("L'auteur(e) a été modifié avec succès", "modification d'auteur(e)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // mise à jour du tableau des auteurs
                        dataGridView_auteurs.DataSource = auteur.listeauteurs(false);
                    }
                    else
                    {
                        MessageBox.Show("La modification pour l'auteur(e) n'a pas fonctionné.", "Modification d'auteur(e) en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"L'Id de l'auteur(e) n'est pas valide.", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //permettre de cliquer et afficher les infos du tableau dans les champs
        private void dataGridView_auteurs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            texte_id.Text = dataGridView_auteurs.CurrentRow.Cells[0].Value.ToString();
            texte_prenom.Text = dataGridView_auteurs.CurrentRow.Cells[1].Value.ToString();
            texte_nom.Text = dataGridView_auteurs.CurrentRow.Cells[2].Value.ToString();
            texte_education.Text = dataGridView_auteurs.CurrentRow.Cells[3].Value.ToString();
            texte_biographie.Text = dataGridView_auteurs.CurrentRow.Cells[4].Value.ToString();
        }
      
       


        // Bouton pour supprimer un auteur
        private void bouton_supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(texte_id.Text);

                //Demander une confirmation avant de supprimer
                if(MessageBox.Show("Voulez-vous vraiment supprimer l'auteur(e)?", "Confirmation de Suppression",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (auteur.supprimerauteur(id))
                    {
                        MessageBox.Show("L'auteur(e) à été supprimé avec succès", "Supprimer un(e) auteur", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // nettoyer les champs
                        texte_id.Text = "";
                        texte_prenom.Text = "";
                        texte_nom.Text = "";
                        texte_education.Text = "";
                        texte_biographie.Text = "";

                        // mise à jour du tableau des auteurs
                        dataGridView_auteurs.DataSource = auteur.listeauteurs(false);

                        //mise à jour du compteur de auteurs
                        label_compteur_auteurs.Text = auteur.listeauteurs(false).Rows.Count.ToString() + " auteurs";
                    }
                    else
                    {
                        MessageBox.Show("L'auteur(e) n'a pas été supprimer", "La suppression d'auteur(e) est en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "L'id est invalide");
            }
        }
        //Montre les livres de l'auteur(e) sélectionné(e)
        private void bouton_liste_livres_auteur_Click(object sender, EventArgs e)
        {
            Liste_livres_formulaire lislivautf = new Liste_livres_formulaire();
            lislivautf.Show();
        }

        //Exporte la liste dans un fichier texte
        private void bouton_voir_oeuvre_auteur_Click(object sender, EventArgs e)
        {
            // sera fait plus tard.
        }
    }
}
