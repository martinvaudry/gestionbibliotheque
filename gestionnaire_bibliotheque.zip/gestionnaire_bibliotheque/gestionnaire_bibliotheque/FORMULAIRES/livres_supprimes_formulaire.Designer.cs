﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class livres_supprimes_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_supprimer_id = new System.Windows.Forms.Button();
            this.label_supprimer_id = new System.Windows.Forms.Label();
            this.numericUpDown_livre_id = new System.Windows.Forms.NumericUpDown();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_livre_id)).BeginInit();
            this.SuspendLayout();
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(509, 2);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 3;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(0, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(546, 75);
            this.label1.TabIndex = 2;
            this.label1.Text = "Supprimer un livre";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightPink;
            this.panel1.Controls.Add(this.numericUpDown_livre_id);
            this.panel1.Controls.Add(this.button_supprimer_id);
            this.panel1.Controls.Add(this.label_supprimer_id);
            this.panel1.Location = new System.Drawing.Point(9, 84);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(525, 154);
            this.panel1.TabIndex = 4;
            // 
            // button_supprimer_id
            // 
            this.button_supprimer_id.BackColor = System.Drawing.Color.Crimson;
            this.button_supprimer_id.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_supprimer_id.FlatAppearance.BorderSize = 2;
            this.button_supprimer_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_supprimer_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F);
            this.button_supprimer_id.ForeColor = System.Drawing.Color.LightBlue;
            this.button_supprimer_id.Location = new System.Drawing.Point(96, 82);
            this.button_supprimer_id.Name = "button_supprimer_id";
            this.button_supprimer_id.Size = new System.Drawing.Size(313, 38);
            this.button_supprimer_id.TabIndex = 47;
            this.button_supprimer_id.Text = "Supprimer ce livre";
            this.button_supprimer_id.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_supprimer_id.UseVisualStyleBackColor = false;
            this.button_supprimer_id.Click += new System.EventHandler(this.button_supprimer_id_Click);
            // 
            // label_supprimer_id
            // 
            this.label_supprimer_id.AutoSize = true;
            this.label_supprimer_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_supprimer_id.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_supprimer_id.Location = new System.Drawing.Point(92, 33);
            this.label_supprimer_id.Name = "label_supprimer_id";
            this.label_supprimer_id.Size = new System.Drawing.Size(236, 24);
            this.label_supprimer_id.TabIndex = 45;
            this.label_supprimer_id.Text = "Inscrivez le id du livre:";
            // 
            // numericUpDown_livre_id
            // 
            this.numericUpDown_livre_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown_livre_id.ForeColor = System.Drawing.Color.MidnightBlue;
            this.numericUpDown_livre_id.Location = new System.Drawing.Point(334, 31);
            this.numericUpDown_livre_id.Name = "numericUpDown_livre_id";
            this.numericUpDown_livre_id.Size = new System.Drawing.Size(75, 32);
            this.numericUpDown_livre_id.TabIndex = 48;
            // 
            // livres_supprimes_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(544, 250);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Label_fermeture);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "livres_supprimes_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "livres_supprimes_formulaire";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_livre_id)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_supprimer_id;
        private System.Windows.Forms.Label label_supprimer_id;
        private System.Windows.Forms.NumericUpDown numericUpDown_livre_id;
    }
}