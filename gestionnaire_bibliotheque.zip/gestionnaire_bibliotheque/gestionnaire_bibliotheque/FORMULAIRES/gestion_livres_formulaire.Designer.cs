﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class gestion_livres_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.gestion_auteurs = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.label_prenom = new System.Windows.Forms.Label();
            this.texte_id = new System.Windows.Forms.TextBox();
            this.texte_isbn = new System.Windows.Forms.TextBox();
            this.label_titre = new System.Windows.Forms.Label();
            this.texte_titre = new System.Windows.Forms.TextBox();
            this.label_auteur = new System.Windows.Forms.Label();
            this.texte_publie = new System.Windows.Forms.TextBox();
            this.label_biographie = new System.Windows.Forms.Label();
            this.texte_description = new System.Windows.Forms.RichTextBox();
            this.panel_ajouter = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.texte_prix = new System.Windows.Forms.TextBox();
            this.label_prix = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bouton_efface_champs = new System.Windows.Forms.Button();
            this.bouton_ajoutlivre = new System.Windows.Forms.Button();
            this.label_auteur_id = new System.Windows.Forms.Label();
            this.bouton_selection_auteur = new System.Windows.Forms.Button();
            this.texte_auteur_nomcomplet = new System.Windows.Forms.TextBox();
            this.numericUpDown_pages = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_quantite = new System.Windows.Forms.NumericUpDown();
            this.texte_genre = new System.Windows.Forms.ComboBox();
            this.bouton_teledeposer = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox_pochette = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker_recu = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bouton_ajouter = new System.Windows.Forms.Button();
            this.bouton_modifier = new System.Windows.Forms.Button();
            this.bouton_liste_de_livres = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bouton_supprimer = new System.Windows.Forms.Button();
            this.label_menu = new System.Windows.Forms.Label();
            this.label_compteur_livres = new System.Windows.Forms.Label();
            this.panel_modifier = new System.Windows.Forms.Panel();
            this.button_cherche_isbn = new System.Windows.Forms.Button();
            this.button_cherche_id = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_prix_modifier = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.enregistrer_modifications = new System.Windows.Forms.Button();
            this.label_auteur_id_modifier = new System.Windows.Forms.Label();
            this.bouton_selection_auteur_modifier = new System.Windows.Forms.Button();
            this.textBox_auteur_modifier = new System.Windows.Forms.TextBox();
            this.numericUpDown_pages_modifier = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_quantite_modifier = new System.Windows.Forms.NumericUpDown();
            this.comboBox_genre_modifer = new System.Windows.Forms.ComboBox();
            this.button_teledeposer_modifier = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox_pochette_modifier = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dateTimePicker_date_recu_modifier = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.richTextBox_description_modifier = new System.Windows.Forms.RichTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox_publie_modifier = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox_titre_modifier = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox_isbn_modifier = new System.Windows.Forms.TextBox();
            this.textBox_id_modifier = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel_montre_livres = new System.Windows.Forms.Panel();
            this.button_selction_supprimer_livre = new System.Windows.Forms.Button();
            this.button_selection_modifier = new System.Windows.Forms.Button();
            this.dataGridView_liste_livres = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_ajouter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_quantite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pochette)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel_modifier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pages_modifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_quantite_modifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pochette_modifier)).BeginInit();
            this.panel_montre_livres.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_liste_livres)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Label_fermeture);
            this.panel2.Controls.Add(this.gestion_auteurs);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1488, 165);
            this.panel2.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightBlue;
            this.pictureBox1.ImageLocation = "../../IMAGES/livres_ico.png";
            this.pictureBox1.Location = new System.Drawing.Point(13, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(209, 158);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(1452, 8);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 3;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // gestion_auteurs
            // 
            this.gestion_auteurs.BackColor = System.Drawing.Color.LightBlue;
            this.gestion_auteurs.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gestion_auteurs.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gestion_auteurs.Location = new System.Drawing.Point(235, 0);
            this.gestion_auteurs.Name = "gestion_auteurs";
            this.gestion_auteurs.Size = new System.Drawing.Size(1253, 165);
            this.gestion_auteurs.TabIndex = 1;
            this.gestion_auteurs.Text = "Gestion des livres";
            this.gestion_auteurs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_id.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_id.Location = new System.Drawing.Point(86, 24);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(40, 24);
            this.label_id.TabIndex = 4;
            this.label_id.Text = "ID:";
            // 
            // label_prenom
            // 
            this.label_prenom.AutoSize = true;
            this.label_prenom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_prenom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_prenom.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_prenom.Location = new System.Drawing.Point(57, 80);
            this.label_prenom.Name = "label_prenom";
            this.label_prenom.Size = new System.Drawing.Size(69, 24);
            this.label_prenom.TabIndex = 5;
            this.label_prenom.Text = "ISBN:";
            // 
            // texte_id
            // 
            this.texte_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_id.Location = new System.Drawing.Point(139, 21);
            this.texte_id.Name = "texte_id";
            this.texte_id.Size = new System.Drawing.Size(137, 32);
            this.texte_id.TabIndex = 6;
            // 
            // texte_isbn
            // 
            this.texte_isbn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_isbn.Location = new System.Drawing.Point(139, 77);
            this.texte_isbn.Name = "texte_isbn";
            this.texte_isbn.Size = new System.Drawing.Size(398, 32);
            this.texte_isbn.TabIndex = 7;
            // 
            // label_titre
            // 
            this.label_titre.AutoSize = true;
            this.label_titre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_titre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_titre.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_titre.Location = new System.Drawing.Point(61, 136);
            this.label_titre.Name = "label_titre";
            this.label_titre.Size = new System.Drawing.Size(64, 24);
            this.label_titre.TabIndex = 8;
            this.label_titre.Text = "Titre:";
            // 
            // texte_titre
            // 
            this.texte_titre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_titre.Location = new System.Drawing.Point(139, 133);
            this.texte_titre.Name = "texte_titre";
            this.texte_titre.Size = new System.Drawing.Size(398, 32);
            this.texte_titre.TabIndex = 9;
            // 
            // label_auteur
            // 
            this.label_auteur.AutoSize = true;
            this.label_auteur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_auteur.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_auteur.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_auteur.Location = new System.Drawing.Point(45, 192);
            this.label_auteur.Name = "label_auteur";
            this.label_auteur.Size = new System.Drawing.Size(80, 24);
            this.label_auteur.TabIndex = 10;
            this.label_auteur.Text = "Genre:";
            // 
            // texte_publie
            // 
            this.texte_publie.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_publie.Location = new System.Drawing.Point(139, 301);
            this.texte_publie.Name = "texte_publie";
            this.texte_publie.Size = new System.Drawing.Size(398, 32);
            this.texte_publie.TabIndex = 11;
            // 
            // label_biographie
            // 
            this.label_biographie.AutoSize = true;
            this.label_biographie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_biographie.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_biographie.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_biographie.Location = new System.Drawing.Point(675, 80);
            this.label_biographie.Name = "label_biographie";
            this.label_biographie.Size = new System.Drawing.Size(135, 24);
            this.label_biographie.TabIndex = 12;
            this.label_biographie.Text = "Description:";
            // 
            // texte_description
            // 
            this.texte_description.Location = new System.Drawing.Point(573, 115);
            this.texte_description.Name = "texte_description";
            this.texte_description.Size = new System.Drawing.Size(333, 386);
            this.texte_description.TabIndex = 15;
            this.texte_description.Text = "";
            // 
            // panel_ajouter
            // 
            this.panel_ajouter.BackColor = System.Drawing.Color.LightBlue;
            this.panel_ajouter.Controls.Add(this.label11);
            this.panel_ajouter.Controls.Add(this.texte_prix);
            this.panel_ajouter.Controls.Add(this.label_prix);
            this.panel_ajouter.Controls.Add(this.label10);
            this.panel_ajouter.Controls.Add(this.label9);
            this.panel_ajouter.Controls.Add(this.label8);
            this.panel_ajouter.Controls.Add(this.label4);
            this.panel_ajouter.Controls.Add(this.bouton_efface_champs);
            this.panel_ajouter.Controls.Add(this.bouton_ajoutlivre);
            this.panel_ajouter.Controls.Add(this.label_auteur_id);
            this.panel_ajouter.Controls.Add(this.bouton_selection_auteur);
            this.panel_ajouter.Controls.Add(this.texte_auteur_nomcomplet);
            this.panel_ajouter.Controls.Add(this.numericUpDown_pages);
            this.panel_ajouter.Controls.Add(this.numericUpDown_quantite);
            this.panel_ajouter.Controls.Add(this.texte_genre);
            this.panel_ajouter.Controls.Add(this.bouton_teledeposer);
            this.panel_ajouter.Controls.Add(this.label7);
            this.panel_ajouter.Controls.Add(this.pictureBox_pochette);
            this.panel_ajouter.Controls.Add(this.label6);
            this.panel_ajouter.Controls.Add(this.dateTimePicker_recu);
            this.panel_ajouter.Controls.Add(this.label5);
            this.panel_ajouter.Controls.Add(this.label3);
            this.panel_ajouter.Controls.Add(this.label2);
            this.panel_ajouter.Controls.Add(this.label1);
            this.panel_ajouter.Controls.Add(this.texte_description);
            this.panel_ajouter.Controls.Add(this.label_biographie);
            this.panel_ajouter.Controls.Add(this.texte_publie);
            this.panel_ajouter.Controls.Add(this.label_auteur);
            this.panel_ajouter.Controls.Add(this.texte_titre);
            this.panel_ajouter.Controls.Add(this.label_titre);
            this.panel_ajouter.Controls.Add(this.texte_isbn);
            this.panel_ajouter.Controls.Add(this.texte_id);
            this.panel_ajouter.Controls.Add(this.label_prenom);
            this.panel_ajouter.Controls.Add(this.label_id);
            this.panel_ajouter.Location = new System.Drawing.Point(246, 185);
            this.panel_ajouter.Name = "panel_ajouter";
            this.panel_ajouter.Size = new System.Drawing.Size(1230, 541);
            this.panel_ajouter.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(513, 364);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 24);
            this.label11.TabIndex = 43;
            this.label11.Text = "$";
            // 
            // texte_prix
            // 
            this.texte_prix.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_prix.Location = new System.Drawing.Point(394, 361);
            this.texte_prix.Name = "texte_prix";
            this.texte_prix.Size = new System.Drawing.Size(143, 32);
            this.texte_prix.TabIndex = 42;
            // 
            // label_prix
            // 
            this.label_prix.AutoSize = true;
            this.label_prix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_prix.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_prix.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_prix.Location = new System.Drawing.Point(320, 363);
            this.label_prix.Name = "label_prix";
            this.label_prix.Size = new System.Drawing.Size(57, 24);
            this.label_prix.TabIndex = 41;
            this.label_prix.Text = "Prix:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(514, 305);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 24);
            this.label10.TabIndex = 40;
            this.label10.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(515, 137);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 24);
            this.label9.TabIndex = 39;
            this.label9.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(513, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 38;
            this.label8.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(255, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 24);
            this.label4.TabIndex = 37;
            this.label4.Text = "*";
            // 
            // bouton_efface_champs
            // 
            this.bouton_efface_champs.BackColor = System.Drawing.Color.Red;
            this.bouton_efface_champs.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_efface_champs.FlatAppearance.BorderSize = 2;
            this.bouton_efface_champs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_efface_champs.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_efface_champs.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_efface_champs.Location = new System.Drawing.Point(309, 467);
            this.bouton_efface_champs.Name = "bouton_efface_champs";
            this.bouton_efface_champs.Size = new System.Drawing.Size(216, 41);
            this.bouton_efface_champs.TabIndex = 36;
            this.bouton_efface_champs.Text = "Effacer les champs";
            this.bouton_efface_champs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_efface_champs.UseVisualStyleBackColor = false;
            this.bouton_efface_champs.Click += new System.EventHandler(this.bouton_efface_champs_Click);
            // 
            // bouton_ajoutlivre
            // 
            this.bouton_ajoutlivre.BackColor = System.Drawing.Color.DarkGreen;
            this.bouton_ajoutlivre.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajoutlivre.FlatAppearance.BorderSize = 2;
            this.bouton_ajoutlivre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_ajoutlivre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_ajoutlivre.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_ajoutlivre.Location = new System.Drawing.Point(45, 467);
            this.bouton_ajoutlivre.Name = "bouton_ajoutlivre";
            this.bouton_ajoutlivre.Size = new System.Drawing.Size(216, 41);
            this.bouton_ajoutlivre.TabIndex = 9;
            this.bouton_ajoutlivre.Text = "  Ajouter un livre";
            this.bouton_ajoutlivre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_ajoutlivre.UseVisualStyleBackColor = false;
            this.bouton_ajoutlivre.Click += new System.EventHandler(this.bouton_ajoutlivre_Click);
            // 
            // label_auteur_id
            // 
            this.label_auteur_id.AutoSize = true;
            this.label_auteur_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_auteur_id.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_auteur_id.Location = new System.Drawing.Point(373, 248);
            this.label_auteur_id.Name = "label_auteur_id";
            this.label_auteur_id.Size = new System.Drawing.Size(40, 24);
            this.label_auteur_id.TabIndex = 35;
            this.label_auteur_id.Text = "ID:";
            // 
            // bouton_selection_auteur
            // 
            this.bouton_selection_auteur.BackColor = System.Drawing.Color.MidnightBlue;
            this.bouton_selection_auteur.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_selection_auteur.FlatAppearance.BorderSize = 2;
            this.bouton_selection_auteur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_selection_auteur.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_selection_auteur.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_selection_auteur.Location = new System.Drawing.Point(414, 244);
            this.bouton_selection_auteur.Name = "bouton_selection_auteur";
            this.bouton_selection_auteur.Size = new System.Drawing.Size(123, 32);
            this.bouton_selection_auteur.TabIndex = 9;
            this.bouton_selection_auteur.Text = "Sélectionner";
            this.bouton_selection_auteur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_selection_auteur.UseVisualStyleBackColor = false;
            this.bouton_selection_auteur.Click += new System.EventHandler(this.bouton_selection_auteur_Click);
            // 
            // texte_auteur_nomcomplet
            // 
            this.texte_auteur_nomcomplet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_auteur_nomcomplet.Location = new System.Drawing.Point(141, 245);
            this.texte_auteur_nomcomplet.Name = "texte_auteur_nomcomplet";
            this.texte_auteur_nomcomplet.Size = new System.Drawing.Size(224, 32);
            this.texte_auteur_nomcomplet.TabIndex = 34;
            // 
            // numericUpDown_pages
            // 
            this.numericUpDown_pages.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown_pages.Location = new System.Drawing.Point(139, 361);
            this.numericUpDown_pages.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericUpDown_pages.Name = "numericUpDown_pages";
            this.numericUpDown_pages.Size = new System.Drawing.Size(137, 32);
            this.numericUpDown_pages.TabIndex = 33;
            // 
            // numericUpDown_quantite
            // 
            this.numericUpDown_quantite.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown_quantite.Location = new System.Drawing.Point(139, 417);
            this.numericUpDown_quantite.Name = "numericUpDown_quantite";
            this.numericUpDown_quantite.Size = new System.Drawing.Size(137, 32);
            this.numericUpDown_quantite.TabIndex = 32;
            // 
            // texte_genre
            // 
            this.texte_genre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texte_genre.FormattingEnabled = true;
            this.texte_genre.Location = new System.Drawing.Point(139, 192);
            this.texte_genre.Name = "texte_genre";
            this.texte_genre.Size = new System.Drawing.Size(226, 32);
            this.texte_genre.TabIndex = 31;
            // 
            // bouton_teledeposer
            // 
            this.bouton_teledeposer.BackColor = System.Drawing.Color.MidnightBlue;
            this.bouton_teledeposer.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_teledeposer.FlatAppearance.BorderSize = 2;
            this.bouton_teledeposer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_teledeposer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_teledeposer.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_teledeposer.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bouton_teledeposer.Location = new System.Drawing.Point(931, 467);
            this.bouton_teledeposer.Name = "bouton_teledeposer";
            this.bouton_teledeposer.Size = new System.Drawing.Size(282, 34);
            this.bouton_teledeposer.TabIndex = 10;
            this.bouton_teledeposer.Text = "  Télédéposer une pochette";
            this.bouton_teledeposer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_teledeposer.UseVisualStyleBackColor = false;
            this.bouton_teledeposer.Click += new System.EventHandler(this.bouton_teledeposer_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label7.Location = new System.Drawing.Point(1002, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 24);
            this.label7.TabIndex = 29;
            this.label7.Text = "Pochette";
            // 
            // pictureBox_pochette
            // 
            this.pictureBox_pochette.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox_pochette.ImageLocation = "../../IMAGES/pochette_template.png";
            this.pictureBox_pochette.Location = new System.Drawing.Point(931, 63);
            this.pictureBox_pochette.Name = "pictureBox_pochette";
            this.pictureBox_pochette.Size = new System.Drawing.Size(282, 386);
            this.pictureBox_pochette.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_pochette.TabIndex = 28;
            this.pictureBox_pochette.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label6.Location = new System.Drawing.Point(6, 304);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 24);
            this.label6.TabIndex = 26;
            this.label6.Text = "Publié par:";
            // 
            // dateTimePicker_recu
            // 
            this.dateTimePicker_recu.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_recu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_recu.Location = new System.Drawing.Point(706, 21);
            this.dateTimePicker_recu.Name = "dateTimePicker_recu";
            this.dateTimePicker_recu.Size = new System.Drawing.Size(200, 32);
            this.dateTimePicker_recu.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label5.Location = new System.Drawing.Point(585, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 24);
            this.label5.TabIndex = 24;
            this.label5.Text = "Date reçu:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(21, 417);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 24);
            this.label3.TabIndex = 20;
            this.label3.Text = "Quantité:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(46, 361);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 24);
            this.label2.TabIndex = 18;
            this.label2.Text = "Pages:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(40, 248);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 16;
            this.label1.Text = "Auteur:";
            // 
            // bouton_ajouter
            // 
            this.bouton_ajouter.BackColor = System.Drawing.Color.LightBlue;
            this.bouton_ajouter.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.FlatAppearance.BorderSize = 2;
            this.bouton_ajouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_ajouter.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_ajouter.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_ajouter.Location = new System.Drawing.Point(12, 80);
            this.bouton_ajouter.Name = "bouton_ajouter";
            this.bouton_ajouter.Size = new System.Drawing.Size(210, 75);
            this.bouton_ajouter.TabIndex = 6;
            this.bouton_ajouter.Text = "  Ajouter";
            this.bouton_ajouter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_ajouter.UseVisualStyleBackColor = false;
            this.bouton_ajouter.Click += new System.EventHandler(this.bouton_ajouter_Click);
            // 
            // bouton_modifier
            // 
            this.bouton_modifier.BackColor = System.Drawing.Color.PaleGreen;
            this.bouton_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.FlatAppearance.BorderSize = 2;
            this.bouton_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_modifier.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_modifier.Location = new System.Drawing.Point(12, 163);
            this.bouton_modifier.Name = "bouton_modifier";
            this.bouton_modifier.Size = new System.Drawing.Size(210, 75);
            this.bouton_modifier.TabIndex = 7;
            this.bouton_modifier.Text = "Modifier";
            this.bouton_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_modifier.UseVisualStyleBackColor = false;
            this.bouton_modifier.Click += new System.EventHandler(this.bouton_modifier_Click);
            // 
            // bouton_liste_de_livres
            // 
            this.bouton_liste_de_livres.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.bouton_liste_de_livres.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_liste_de_livres.FlatAppearance.BorderSize = 2;
            this.bouton_liste_de_livres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_liste_de_livres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_liste_de_livres.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_liste_de_livres.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_liste_de_livres.Location = new System.Drawing.Point(12, 296);
            this.bouton_liste_de_livres.Name = "bouton_liste_de_livres";
            this.bouton_liste_de_livres.Size = new System.Drawing.Size(210, 75);
            this.bouton_liste_de_livres.TabIndex = 8;
            this.bouton_liste_de_livres.Text = "Liste de livres";
            this.bouton_liste_de_livres.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_liste_de_livres.UseVisualStyleBackColor = false;
            this.bouton_liste_de_livres.Click += new System.EventHandler(this.bouton_liste_de_livres_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel3.Controls.Add(this.bouton_supprimer);
            this.panel3.Controls.Add(this.label_menu);
            this.panel3.Controls.Add(this.label_compteur_livres);
            this.panel3.Controls.Add(this.bouton_liste_de_livres);
            this.panel3.Controls.Add(this.bouton_modifier);
            this.panel3.Controls.Add(this.bouton_ajouter);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 165);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(236, 571);
            this.panel3.TabIndex = 6;
            // 
            // bouton_supprimer
            // 
            this.bouton_supprimer.BackColor = System.Drawing.Color.LightPink;
            this.bouton_supprimer.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.FlatAppearance.BorderSize = 2;
            this.bouton_supprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_supprimer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_supprimer.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_supprimer.Location = new System.Drawing.Point(12, 426);
            this.bouton_supprimer.Name = "bouton_supprimer";
            this.bouton_supprimer.Size = new System.Drawing.Size(210, 75);
            this.bouton_supprimer.TabIndex = 46;
            this.bouton_supprimer.Text = "Supprimer";
            this.bouton_supprimer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_supprimer.UseVisualStyleBackColor = false;
            this.bouton_supprimer.Click += new System.EventHandler(this.bouton_supprimer_Click);
            // 
            // label_menu
            // 
            this.label_menu.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_menu.ForeColor = System.Drawing.Color.LightBlue;
            this.label_menu.Location = new System.Drawing.Point(3, 20);
            this.label_menu.Name = "label_menu";
            this.label_menu.Size = new System.Drawing.Size(230, 39);
            this.label_menu.TabIndex = 45;
            this.label_menu.Text = "MENU";
            this.label_menu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_compteur_livres
            // 
            this.label_compteur_livres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_compteur_livres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_compteur_livres.ForeColor = System.Drawing.Color.LightBlue;
            this.label_compteur_livres.Location = new System.Drawing.Point(13, 537);
            this.label_compteur_livres.Name = "label_compteur_livres";
            this.label_compteur_livres.Size = new System.Drawing.Size(209, 24);
            this.label_compteur_livres.TabIndex = 44;
            this.label_compteur_livres.Text = "999999 livres";
            this.label_compteur_livres.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_modifier
            // 
            this.panel_modifier.BackColor = System.Drawing.Color.LightGreen;
            this.panel_modifier.Controls.Add(this.button_cherche_isbn);
            this.panel_modifier.Controls.Add(this.button_cherche_id);
            this.panel_modifier.Controls.Add(this.label12);
            this.panel_modifier.Controls.Add(this.textBox_prix_modifier);
            this.panel_modifier.Controls.Add(this.label13);
            this.panel_modifier.Controls.Add(this.label14);
            this.panel_modifier.Controls.Add(this.label15);
            this.panel_modifier.Controls.Add(this.label17);
            this.panel_modifier.Controls.Add(this.enregistrer_modifications);
            this.panel_modifier.Controls.Add(this.label_auteur_id_modifier);
            this.panel_modifier.Controls.Add(this.bouton_selection_auteur_modifier);
            this.panel_modifier.Controls.Add(this.textBox_auteur_modifier);
            this.panel_modifier.Controls.Add(this.numericUpDown_pages_modifier);
            this.panel_modifier.Controls.Add(this.numericUpDown_quantite_modifier);
            this.panel_modifier.Controls.Add(this.comboBox_genre_modifer);
            this.panel_modifier.Controls.Add(this.button_teledeposer_modifier);
            this.panel_modifier.Controls.Add(this.label19);
            this.panel_modifier.Controls.Add(this.pictureBox_pochette_modifier);
            this.panel_modifier.Controls.Add(this.label20);
            this.panel_modifier.Controls.Add(this.dateTimePicker_date_recu_modifier);
            this.panel_modifier.Controls.Add(this.label21);
            this.panel_modifier.Controls.Add(this.label22);
            this.panel_modifier.Controls.Add(this.label23);
            this.panel_modifier.Controls.Add(this.label24);
            this.panel_modifier.Controls.Add(this.richTextBox_description_modifier);
            this.panel_modifier.Controls.Add(this.label25);
            this.panel_modifier.Controls.Add(this.textBox_publie_modifier);
            this.panel_modifier.Controls.Add(this.label26);
            this.panel_modifier.Controls.Add(this.textBox_titre_modifier);
            this.panel_modifier.Controls.Add(this.label27);
            this.panel_modifier.Controls.Add(this.textBox_isbn_modifier);
            this.panel_modifier.Controls.Add(this.textBox_id_modifier);
            this.panel_modifier.Controls.Add(this.label28);
            this.panel_modifier.Controls.Add(this.label29);
            this.panel_modifier.Location = new System.Drawing.Point(246, 185);
            this.panel_modifier.Name = "panel_modifier";
            this.panel_modifier.Size = new System.Drawing.Size(1230, 541);
            this.panel_modifier.TabIndex = 44;
            // 
            // button_cherche_isbn
            // 
            this.button_cherche_isbn.BackColor = System.Drawing.Color.MidnightBlue;
            this.button_cherche_isbn.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_cherche_isbn.FlatAppearance.BorderSize = 2;
            this.button_cherche_isbn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_cherche_isbn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cherche_isbn.ForeColor = System.Drawing.Color.LightBlue;
            this.button_cherche_isbn.Location = new System.Drawing.Point(345, 77);
            this.button_cherche_isbn.Name = "button_cherche_isbn";
            this.button_cherche_isbn.Size = new System.Drawing.Size(192, 32);
            this.button_cherche_isbn.TabIndex = 45;
            this.button_cherche_isbn.Text = "Chercher un livre par ISBN";
            this.button_cherche_isbn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_cherche_isbn.UseVisualStyleBackColor = false;
            this.button_cherche_isbn.Click += new System.EventHandler(this.button_cherche_isbn_Click);
            // 
            // button_cherche_id
            // 
            this.button_cherche_id.BackColor = System.Drawing.Color.MidnightBlue;
            this.button_cherche_id.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_cherche_id.FlatAppearance.BorderSize = 2;
            this.button_cherche_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_cherche_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cherche_id.ForeColor = System.Drawing.Color.LightBlue;
            this.button_cherche_id.Location = new System.Drawing.Point(345, 21);
            this.button_cherche_id.Name = "button_cherche_id";
            this.button_cherche_id.Size = new System.Drawing.Size(192, 32);
            this.button_cherche_id.TabIndex = 44;
            this.button_cherche_id.Text = "Chercher un livre par ID";
            this.button_cherche_id.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_cherche_id.UseVisualStyleBackColor = false;
            this.button_cherche_id.Click += new System.EventHandler(this.button_cherche_id_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(513, 364);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 24);
            this.label12.TabIndex = 43;
            this.label12.Text = "$";
            // 
            // textBox_prix_modifier
            // 
            this.textBox_prix_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_prix_modifier.Location = new System.Drawing.Point(394, 361);
            this.textBox_prix_modifier.Name = "textBox_prix_modifier";
            this.textBox_prix_modifier.Size = new System.Drawing.Size(143, 32);
            this.textBox_prix_modifier.TabIndex = 42;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label13.Location = new System.Drawing.Point(320, 363);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 24);
            this.label13.TabIndex = 41;
            this.label13.Text = "Prix:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(514, 305);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(19, 24);
            this.label14.TabIndex = 40;
            this.label14.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(515, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(19, 24);
            this.label15.TabIndex = 39;
            this.label15.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(255, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(19, 24);
            this.label17.TabIndex = 37;
            this.label17.Text = "*";
            // 
            // enregistrer_modifications
            // 
            this.enregistrer_modifications.BackColor = System.Drawing.Color.DarkGreen;
            this.enregistrer_modifications.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.enregistrer_modifications.FlatAppearance.BorderSize = 2;
            this.enregistrer_modifications.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.enregistrer_modifications.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enregistrer_modifications.ForeColor = System.Drawing.Color.LightBlue;
            this.enregistrer_modifications.Location = new System.Drawing.Point(141, 467);
            this.enregistrer_modifications.Name = "enregistrer_modifications";
            this.enregistrer_modifications.Size = new System.Drawing.Size(313, 41);
            this.enregistrer_modifications.TabIndex = 9;
            this.enregistrer_modifications.Text = "Enregister les modifications";
            this.enregistrer_modifications.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.enregistrer_modifications.UseVisualStyleBackColor = false;
            this.enregistrer_modifications.Click += new System.EventHandler(this.enregistrer_modifications_Click);
            // 
            // label_auteur_id_modifier
            // 
            this.label_auteur_id_modifier.AutoSize = true;
            this.label_auteur_id_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_auteur_id_modifier.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_auteur_id_modifier.Location = new System.Drawing.Point(373, 248);
            this.label_auteur_id_modifier.Name = "label_auteur_id_modifier";
            this.label_auteur_id_modifier.Size = new System.Drawing.Size(40, 24);
            this.label_auteur_id_modifier.TabIndex = 35;
            this.label_auteur_id_modifier.Text = "ID:";
            // 
            // bouton_selection_auteur_modifier
            // 
            this.bouton_selection_auteur_modifier.BackColor = System.Drawing.Color.MidnightBlue;
            this.bouton_selection_auteur_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_selection_auteur_modifier.FlatAppearance.BorderSize = 2;
            this.bouton_selection_auteur_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_selection_auteur_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_selection_auteur_modifier.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_selection_auteur_modifier.Location = new System.Drawing.Point(414, 244);
            this.bouton_selection_auteur_modifier.Name = "bouton_selection_auteur_modifier";
            this.bouton_selection_auteur_modifier.Size = new System.Drawing.Size(123, 32);
            this.bouton_selection_auteur_modifier.TabIndex = 9;
            this.bouton_selection_auteur_modifier.Text = "Sélectionner";
            this.bouton_selection_auteur_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_selection_auteur_modifier.UseVisualStyleBackColor = false;
            this.bouton_selection_auteur_modifier.Click += new System.EventHandler(this.bouton_selection_auteur_modifier_Click);
            // 
            // textBox_auteur_modifier
            // 
            this.textBox_auteur_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_auteur_modifier.Location = new System.Drawing.Point(141, 245);
            this.textBox_auteur_modifier.Name = "textBox_auteur_modifier";
            this.textBox_auteur_modifier.Size = new System.Drawing.Size(224, 32);
            this.textBox_auteur_modifier.TabIndex = 34;
            // 
            // numericUpDown_pages_modifier
            // 
            this.numericUpDown_pages_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown_pages_modifier.Location = new System.Drawing.Point(139, 361);
            this.numericUpDown_pages_modifier.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericUpDown_pages_modifier.Name = "numericUpDown_pages_modifier";
            this.numericUpDown_pages_modifier.Size = new System.Drawing.Size(137, 32);
            this.numericUpDown_pages_modifier.TabIndex = 33;
            // 
            // numericUpDown_quantite_modifier
            // 
            this.numericUpDown_quantite_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown_quantite_modifier.Location = new System.Drawing.Point(139, 417);
            this.numericUpDown_quantite_modifier.Name = "numericUpDown_quantite_modifier";
            this.numericUpDown_quantite_modifier.Size = new System.Drawing.Size(137, 32);
            this.numericUpDown_quantite_modifier.TabIndex = 32;
            // 
            // comboBox_genre_modifer
            // 
            this.comboBox_genre_modifer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_genre_modifer.FormattingEnabled = true;
            this.comboBox_genre_modifer.Location = new System.Drawing.Point(139, 192);
            this.comboBox_genre_modifer.Name = "comboBox_genre_modifer";
            this.comboBox_genre_modifer.Size = new System.Drawing.Size(226, 32);
            this.comboBox_genre_modifer.TabIndex = 31;
            // 
            // button_teledeposer_modifier
            // 
            this.button_teledeposer_modifier.BackColor = System.Drawing.Color.MidnightBlue;
            this.button_teledeposer_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_teledeposer_modifier.FlatAppearance.BorderSize = 2;
            this.button_teledeposer_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_teledeposer_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_teledeposer_modifier.ForeColor = System.Drawing.Color.LightBlue;
            this.button_teledeposer_modifier.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_teledeposer_modifier.Location = new System.Drawing.Point(931, 467);
            this.button_teledeposer_modifier.Name = "button_teledeposer_modifier";
            this.button_teledeposer_modifier.Size = new System.Drawing.Size(282, 34);
            this.button_teledeposer_modifier.TabIndex = 10;
            this.button_teledeposer_modifier.Text = "  Télédéposer";
            this.button_teledeposer_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_teledeposer_modifier.UseVisualStyleBackColor = false;
            this.button_teledeposer_modifier.Click += new System.EventHandler(this.button_teledeposer_modifier_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label19.Location = new System.Drawing.Point(1002, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 24);
            this.label19.TabIndex = 29;
            this.label19.Text = "Pochette";
            // 
            // pictureBox_pochette_modifier
            // 
            this.pictureBox_pochette_modifier.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox_pochette_modifier.ImageLocation = "../../IMAGES/pochette_template.png";
            this.pictureBox_pochette_modifier.Location = new System.Drawing.Point(931, 63);
            this.pictureBox_pochette_modifier.Name = "pictureBox_pochette_modifier";
            this.pictureBox_pochette_modifier.Size = new System.Drawing.Size(282, 386);
            this.pictureBox_pochette_modifier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_pochette_modifier.TabIndex = 28;
            this.pictureBox_pochette_modifier.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label20.Location = new System.Drawing.Point(6, 304);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 24);
            this.label20.TabIndex = 26;
            this.label20.Text = "Publié par:";
            // 
            // dateTimePicker_date_recu_modifier
            // 
            this.dateTimePicker_date_recu_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_date_recu_modifier.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_date_recu_modifier.Location = new System.Drawing.Point(706, 21);
            this.dateTimePicker_date_recu_modifier.Name = "dateTimePicker_date_recu_modifier";
            this.dateTimePicker_date_recu_modifier.Size = new System.Drawing.Size(200, 32);
            this.dateTimePicker_date_recu_modifier.TabIndex = 25;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label21.Location = new System.Drawing.Point(585, 24);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 24);
            this.label21.TabIndex = 24;
            this.label21.Text = "Date reçu:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label22.Location = new System.Drawing.Point(21, 417);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(104, 24);
            this.label22.TabIndex = 20;
            this.label22.Text = "Quantité:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label23.Location = new System.Drawing.Point(46, 361);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 24);
            this.label23.TabIndex = 18;
            this.label23.Text = "Pages:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label24.Location = new System.Drawing.Point(40, 248);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 24);
            this.label24.TabIndex = 16;
            this.label24.Text = "Auteur:";
            // 
            // richTextBox_description_modifier
            // 
            this.richTextBox_description_modifier.Location = new System.Drawing.Point(573, 115);
            this.richTextBox_description_modifier.Name = "richTextBox_description_modifier";
            this.richTextBox_description_modifier.Size = new System.Drawing.Size(333, 386);
            this.richTextBox_description_modifier.TabIndex = 15;
            this.richTextBox_description_modifier.Text = "";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label25.Location = new System.Drawing.Point(675, 80);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(135, 24);
            this.label25.TabIndex = 12;
            this.label25.Text = "Description:";
            // 
            // textBox_publie_modifier
            // 
            this.textBox_publie_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_publie_modifier.Location = new System.Drawing.Point(139, 301);
            this.textBox_publie_modifier.Name = "textBox_publie_modifier";
            this.textBox_publie_modifier.Size = new System.Drawing.Size(398, 32);
            this.textBox_publie_modifier.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label26.Location = new System.Drawing.Point(45, 192);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(80, 24);
            this.label26.TabIndex = 10;
            this.label26.Text = "Genre:";
            // 
            // textBox_titre_modifier
            // 
            this.textBox_titre_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_titre_modifier.Location = new System.Drawing.Point(139, 133);
            this.textBox_titre_modifier.Name = "textBox_titre_modifier";
            this.textBox_titre_modifier.Size = new System.Drawing.Size(398, 32);
            this.textBox_titre_modifier.TabIndex = 9;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label27.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label27.Location = new System.Drawing.Point(61, 136);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(64, 24);
            this.label27.TabIndex = 8;
            this.label27.Text = "Titre:";
            // 
            // textBox_isbn_modifier
            // 
            this.textBox_isbn_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_isbn_modifier.Location = new System.Drawing.Point(139, 77);
            this.textBox_isbn_modifier.Name = "textBox_isbn_modifier";
            this.textBox_isbn_modifier.Size = new System.Drawing.Size(185, 32);
            this.textBox_isbn_modifier.TabIndex = 7;
            // 
            // textBox_id_modifier
            // 
            this.textBox_id_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_id_modifier.Location = new System.Drawing.Point(139, 21);
            this.textBox_id_modifier.Name = "textBox_id_modifier";
            this.textBox_id_modifier.Size = new System.Drawing.Size(137, 32);
            this.textBox_id_modifier.TabIndex = 6;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label28.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label28.Location = new System.Drawing.Point(57, 80);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 24);
            this.label28.TabIndex = 5;
            this.label28.Text = "ISBN:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label29.Location = new System.Drawing.Point(86, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 24);
            this.label29.TabIndex = 4;
            this.label29.Text = "ID:";
            // 
            // panel_montre_livres
            // 
            this.panel_montre_livres.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.panel_montre_livres.Controls.Add(this.button_selction_supprimer_livre);
            this.panel_montre_livres.Controls.Add(this.button_selection_modifier);
            this.panel_montre_livres.Controls.Add(this.dataGridView_liste_livres);
            this.panel_montre_livres.Location = new System.Drawing.Point(246, 185);
            this.panel_montre_livres.Name = "panel_montre_livres";
            this.panel_montre_livres.Size = new System.Drawing.Size(1230, 541);
            this.panel_montre_livres.TabIndex = 46;
            // 
            // button_selction_supprimer_livre
            // 
            this.button_selction_supprimer_livre.BackColor = System.Drawing.Color.Crimson;
            this.button_selction_supprimer_livre.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_selction_supprimer_livre.FlatAppearance.BorderSize = 2;
            this.button_selction_supprimer_livre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_selction_supprimer_livre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F);
            this.button_selction_supprimer_livre.ForeColor = System.Drawing.Color.LightBlue;
            this.button_selction_supprimer_livre.Location = new System.Drawing.Point(910, 479);
            this.button_selction_supprimer_livre.Name = "button_selction_supprimer_livre";
            this.button_selction_supprimer_livre.Size = new System.Drawing.Size(313, 38);
            this.button_selction_supprimer_livre.TabIndex = 49;
            this.button_selction_supprimer_livre.Text = "Supprimer ce livre";
            this.button_selction_supprimer_livre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_selction_supprimer_livre.UseVisualStyleBackColor = false;
            this.button_selction_supprimer_livre.Click += new System.EventHandler(this.button_selction_supprimer_livre_Click);
            // 
            // button_selection_modifier
            // 
            this.button_selection_modifier.BackColor = System.Drawing.Color.PaleGreen;
            this.button_selection_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.button_selection_modifier.FlatAppearance.BorderSize = 2;
            this.button_selection_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_selection_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F);
            this.button_selection_modifier.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button_selection_modifier.Location = new System.Drawing.Point(563, 479);
            this.button_selection_modifier.Name = "button_selection_modifier";
            this.button_selection_modifier.Size = new System.Drawing.Size(313, 38);
            this.button_selection_modifier.TabIndex = 48;
            this.button_selection_modifier.Text = "Modifier ce livre";
            this.button_selection_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_selection_modifier.UseVisualStyleBackColor = false;
            this.button_selection_modifier.Click += new System.EventHandler(this.button_selection_modifier_Click);
            // 
            // dataGridView_liste_livres
            // 
            this.dataGridView_liste_livres.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_liste_livres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_liste_livres.GridColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView_liste_livres.Location = new System.Drawing.Point(6, 11);
            this.dataGridView_liste_livres.Name = "dataGridView_liste_livres";
            this.dataGridView_liste_livres.Size = new System.Drawing.Size(1217, 438);
            this.dataGridView_liste_livres.TabIndex = 0;
            // 
            // gestion_livres_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1488, 736);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_montre_livres);
            this.Controls.Add(this.panel_ajouter);
            this.Controls.Add(this.panel_modifier);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "gestion_livres_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "gestion_livres";
            this.Load += new System.EventHandler(this.gestion_livres_formulaire_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_ajouter.ResumeLayout(false);
            this.panel_ajouter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_quantite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pochette)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel_modifier.ResumeLayout(false);
            this.panel_modifier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pages_modifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_quantite_modifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pochette_modifier)).EndInit();
            this.panel_montre_livres.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_liste_livres)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Label gestion_auteurs;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.Label label_prenom;
        private System.Windows.Forms.TextBox texte_id;
        private System.Windows.Forms.TextBox texte_isbn;
        private System.Windows.Forms.Label label_titre;
        private System.Windows.Forms.TextBox texte_titre;
        private System.Windows.Forms.Label label_auteur;
        private System.Windows.Forms.TextBox texte_publie;
        private System.Windows.Forms.Label label_biographie;
        private System.Windows.Forms.RichTextBox texte_description;
        private System.Windows.Forms.Panel panel_ajouter;
        private System.Windows.Forms.Button bouton_ajouter;
        private System.Windows.Forms.Button bouton_modifier;
        private System.Windows.Forms.Button bouton_liste_de_livres;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker_recu;
        private System.Windows.Forms.PictureBox pictureBox_pochette;
        private System.Windows.Forms.Button bouton_teledeposer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox texte_genre;
        private System.Windows.Forms.NumericUpDown numericUpDown_pages;
        private System.Windows.Forms.NumericUpDown numericUpDown_quantite;
        private System.Windows.Forms.Button bouton_selection_auteur;
        private System.Windows.Forms.Button bouton_ajoutlivre;
        public System.Windows.Forms.TextBox texte_auteur_nomcomplet;
        public System.Windows.Forms.Label label_auteur_id;
        private System.Windows.Forms.Button bouton_efface_champs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox texte_prix;
        private System.Windows.Forms.Label label_prix;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_compteur_livres;
        private System.Windows.Forms.Panel panel_modifier;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_prix_modifier;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button enregistrer_modifications;
        public System.Windows.Forms.Label label_auteur_id_modifier;
        private System.Windows.Forms.Button bouton_selection_auteur_modifier;
        public System.Windows.Forms.TextBox textBox_auteur_modifier;
        private System.Windows.Forms.NumericUpDown numericUpDown_pages_modifier;
        private System.Windows.Forms.NumericUpDown numericUpDown_quantite_modifier;
        private System.Windows.Forms.ComboBox comboBox_genre_modifer;
        private System.Windows.Forms.Button button_teledeposer_modifier;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox_pochette_modifier;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker dateTimePicker_date_recu_modifier;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox_description_modifier;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox_publie_modifier;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_titre_modifier;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox_isbn_modifier;
        private System.Windows.Forms.TextBox textBox_id_modifier;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button_cherche_isbn;
        private System.Windows.Forms.Button button_cherche_id;
        private System.Windows.Forms.Label label_menu;
        private System.Windows.Forms.Button bouton_supprimer;
        private System.Windows.Forms.Panel panel_montre_livres;
        private System.Windows.Forms.DataGridView dataGridView_liste_livres;
        private System.Windows.Forms.Button button_selction_supprimer_livre;
        private System.Windows.Forms.Button button_selection_modifier;
    }
}