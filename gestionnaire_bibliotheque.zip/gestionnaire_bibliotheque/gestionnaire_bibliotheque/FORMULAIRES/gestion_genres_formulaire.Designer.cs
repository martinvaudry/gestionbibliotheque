﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class gestion_genres_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.genre_usager = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bouton_supprimer = new System.Windows.Forms.Button();
            this.bouton_modifier = new System.Windows.Forms.Button();
            this.bouton_ajouter = new System.Windows.Forms.Button();
            this.dataGridView_genre = new System.Windows.Forms.DataGridView();
            this.texte_nom = new System.Windows.Forms.TextBox();
            this.texte_id = new System.Windows.Forms.TextBox();
            this.label_nom = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_genre)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // genre_usager
            // 
            this.genre_usager.BackColor = System.Drawing.Color.LightBlue;
            this.genre_usager.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genre_usager.ForeColor = System.Drawing.Color.MidnightBlue;
            this.genre_usager.Location = new System.Drawing.Point(263, 0);
            this.genre_usager.Name = "genre_usager";
            this.genre_usager.Size = new System.Drawing.Size(1004, 165);
            this.genre_usager.TabIndex = 1;
            this.genre_usager.Text = "Genre des livres";
            this.genre_usager.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.bouton_supprimer);
            this.panel1.Controls.Add(this.bouton_modifier);
            this.panel1.Controls.Add(this.bouton_ajouter);
            this.panel1.Controls.Add(this.dataGridView_genre);
            this.panel1.Controls.Add(this.texte_nom);
            this.panel1.Controls.Add(this.texte_id);
            this.panel1.Controls.Add(this.label_nom);
            this.panel1.Controls.Add(this.label_ID);
            this.panel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(21, 190);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1234, 414);
            this.panel1.TabIndex = 2;
            // 
            // bouton_supprimer
            // 
            this.bouton_supprimer.BackColor = System.Drawing.Color.White;
            this.bouton_supprimer.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.FlatAppearance.BorderSize = 2;
            this.bouton_supprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_supprimer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_supprimer.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_supprimer.Location = new System.Drawing.Point(352, 329);
            this.bouton_supprimer.Name = "bouton_supprimer";
            this.bouton_supprimer.Size = new System.Drawing.Size(171, 52);
            this.bouton_supprimer.TabIndex = 7;
            this.bouton_supprimer.Text = "  Supprimer";
            this.bouton_supprimer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_supprimer.UseVisualStyleBackColor = false;
            this.bouton_supprimer.Click += new System.EventHandler(this.bouton_supprimer_Click);
            // 
            // bouton_modifier
            // 
            this.bouton_modifier.BackColor = System.Drawing.Color.White;
            this.bouton_modifier.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.FlatAppearance.BorderSize = 2;
            this.bouton_modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_modifier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_modifier.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_modifier.Location = new System.Drawing.Point(175, 329);
            this.bouton_modifier.Name = "bouton_modifier";
            this.bouton_modifier.Size = new System.Drawing.Size(165, 52);
            this.bouton_modifier.TabIndex = 6;
            this.bouton_modifier.Text = "  Modifier";
            this.bouton_modifier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_modifier.UseVisualStyleBackColor = false;
            this.bouton_modifier.Click += new System.EventHandler(this.bouton_modifier_Click);
            // 
            // bouton_ajouter
            // 
            this.bouton_ajouter.BackColor = System.Drawing.Color.White;
            this.bouton_ajouter.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.FlatAppearance.BorderSize = 2;
            this.bouton_ajouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_ajouter.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_ajouter.ForeColor = System.Drawing.Color.MidnightBlue;
            this.bouton_ajouter.Location = new System.Drawing.Point(27, 329);
            this.bouton_ajouter.Name = "bouton_ajouter";
            this.bouton_ajouter.Size = new System.Drawing.Size(135, 52);
            this.bouton_ajouter.TabIndex = 5;
            this.bouton_ajouter.Text = "  Ajouter";
            this.bouton_ajouter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_ajouter.UseVisualStyleBackColor = false;
            this.bouton_ajouter.Click += new System.EventHandler(this.bouton_ajout_Click);
            // 
            // dataGridView_genre
            // 
            this.dataGridView_genre.AllowUserToAddRows = false;
            this.dataGridView_genre.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_genre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_genre.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_genre.Location = new System.Drawing.Point(540, 26);
            this.dataGridView_genre.Name = "dataGridView_genre";
            this.dataGridView_genre.RowTemplate.Height = 26;
            this.dataGridView_genre.Size = new System.Drawing.Size(678, 355);
            this.dataGridView_genre.TabIndex = 4;
            this.dataGridView_genre.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_genre_CellClick);
            // 
            // texte_nom
            // 
            this.texte_nom.Location = new System.Drawing.Point(168, 96);
            this.texte_nom.Name = "texte_nom";
            this.texte_nom.Size = new System.Drawing.Size(355, 50);
            this.texte_nom.TabIndex = 3;
            // 
            // texte_id
            // 
            this.texte_id.Location = new System.Drawing.Point(168, 38);
            this.texte_id.Name = "texte_id";
            this.texte_id.Size = new System.Drawing.Size(176, 50);
            this.texte_id.TabIndex = 2;
            // 
            // label_nom
            // 
            this.label_nom.AutoSize = true;
            this.label_nom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_nom.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_nom.Location = new System.Drawing.Point(35, 96);
            this.label_nom.Name = "label_nom";
            this.label_nom.Size = new System.Drawing.Size(114, 43);
            this.label_nom.TabIndex = 1;
            this.label_nom.Text = "Nom:";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_ID.Location = new System.Drawing.Point(79, 38);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(70, 43);
            this.label_ID.TabIndex = 0;
            this.label_ID.Text = "ID:";
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(1231, 9);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 3;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Label_fermeture);
            this.panel2.Controls.Add(this.genre_usager);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1267, 165);
            this.panel2.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ImageLocation = "../../IMAGES/genresicon.png";
            this.pictureBox1.Location = new System.Drawing.Point(31, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(211, 158);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // gestion_genres_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1267, 646);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "gestion_genres_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "gestion_genres_formulaire";
            this.Load += new System.EventHandler(this.gestion_genres_formulaire_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_genre)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label genre_usager;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_nom;
        private System.Windows.Forms.TextBox texte_nom;
        private System.Windows.Forms.TextBox texte_id;
        private System.Windows.Forms.DataGridView dataGridView_genre;
        private System.Windows.Forms.Button bouton_ajouter;
        private System.Windows.Forms.Button bouton_supprimer;
        private System.Windows.Forms.Button bouton_modifier;
    }
}