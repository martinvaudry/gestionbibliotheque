﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class Connexion_formlaire : Form
    {
        public Connexion_formlaire()
        {
            InitializeComponent();
        }

        private void Connexion_formlaire_Load(object sender, EventArgs e)
        {
            NomUsager_Image.Image = Image.FromFile("../../IMAGES/user.png");
            MotdePasse_Image.Image = Image.FromFile("../../IMAGES/password.png");
        }

        private void Label_fermeture_MouseEnter(object sender, EventArgs e)
        {
            Label_fermeture.ForeColor = Color.DarkRed;
        }

        private void Label_fermeture_MouseLeave(object sender, EventArgs e)
        {
            Label_fermeture.ForeColor = Color.Red;
        }

        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private tableau_de_bord_formulaire tableauForm = null;

        public Connexion_formlaire(tableau_de_bord_formulaire sourceForm)
        {
            tableauForm = sourceForm as tableau_de_bord_formulaire;
            InitializeComponent();
                }
        private void bouton_connexion_Click(object sender, EventArgs e)
        {
            
            LA_BASE_DE_DONNEE.SGB_basededonnee db = new LA_BASE_DE_DONNEE.SGB_basededonnee();

            //création variable local pour saisis des identifiants
            string nom_dusager = texte_usager.Text;
            string mot_de_passe = texte_motdepasse.Text;

            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `app_usagers` WHERE `nom_dusager` =@usn AND `mot_de_passe` =@pass", db.GetConnection());

            command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = nom_dusager;
            command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = mot_de_passe;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            // vérification si l'usager existe dans la base de donnée
            if(table.Rows.Count > 0)
            {
                tableauForm.Enabled = true;
                this.Close();
            }

            else //si non existence
            {
                //vérification si le nom d'usager est vide
                if(nom_dusager.Trim().Equals(""))
                {
                    MessageBox.Show("Entrez votre nom d'usager pour vous connecter", "L'Emplacement pour le Nom d'usager est vide", MessageBoxButtons.OK,MessageBoxIcon.Error);
                }

                //vérification si le mot de passe est vide
                else if(mot_de_passe.Trim().Equals(""))
                {
                    MessageBox.Show("Entrez votre mot de passe pour vous connecter", "L'Emplacement pour le mot de passe est vide", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                //vérification si le data existe
                else
                {
                    MessageBox.Show("Mauvais nom d'usager ou mot de passe", "Erreur de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

   
    }
}
