﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class livres_supprimes_formulaire : Form
    {
        public livres_supprimes_formulaire()
        {
            InitializeComponent();
        }

        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //bouton qui confirme la suppression du livre
        CLASSES.LIVRES LIVRES = new CLASSES.LIVRES();
        private void button_supprimer_id_Click(object sender, EventArgs e)
        {
            //supprime par le id
            int livreId = (int)numericUpDown_livre_id.Value;

            //Demander une confirmation avant de supprimer
            if (MessageBox.Show("Voulez-vous vraiment supprimer ce livre?", "Confirmation de Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (LIVRES.supprimerlivre(livreId))
                {
                    MessageBox.Show("Le livre à été supprimé avec succès", "Supprimer un livre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Le livre n'a pas été supprimer", "La suppression du livre est en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
