﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class tableau_de_bord_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tableau_de_bord_formulaire));
            this.panel1 = new System.Windows.Forms.Panel();
            this.bouton_membres = new System.Windows.Forms.Button();
            this.bouton_usagers = new System.Windows.Forms.Button();
            this.bouton_circulation = new System.Windows.Forms.Button();
            this.bouton_genres = new System.Windows.Forms.Button();
            this.bouton_auteurs = new System.Windows.Forms.Button();
            this.bouton_livres = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SGB_image = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fond_tableau = new System.Windows.Forms.Panel();
            this.panel_dernier_livres = new System.Windows.Forms.Panel();
            this.panel_livre5 = new System.Windows.Forms.Panel();
            this.label_pages_livre5 = new System.Windows.Forms.Label();
            this.panel_livre4 = new System.Windows.Forms.Panel();
            this.label_pages_livre4 = new System.Windows.Forms.Label();
            this.panel_livre2 = new System.Windows.Forms.Panel();
            this.label_pages_livre2 = new System.Windows.Forms.Label();
            this.panel_livre3 = new System.Windows.Forms.Panel();
            this.label_pages_livre3 = new System.Windows.Forms.Label();
            this.panel_livre1 = new System.Windows.Forms.Panel();
            this.label_pages_livre1 = new System.Windows.Forms.Label();
            this.Derniers_livres = new System.Windows.Forms.Label();
            this.Membres_quantites = new System.Windows.Forms.Panel();
            this.label_membres_qtes = new System.Windows.Forms.Label();
            this.membres_label = new System.Windows.Forms.Label();
            this.Auteurs_quantites = new System.Windows.Forms.Panel();
            this.label_auteurs_qtes = new System.Windows.Forms.Label();
            this.Auteurs_label = new System.Windows.Forms.Label();
            this.Livres_quantites = new System.Windows.Forms.Panel();
            this.label_livres_qtes = new System.Windows.Forms.Label();
            this.livres_label = new System.Windows.Forms.Label();
            this.Fermer_bouton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SGB_image)).BeginInit();
            this.fond_tableau.SuspendLayout();
            this.panel_dernier_livres.SuspendLayout();
            this.panel_livre5.SuspendLayout();
            this.panel_livre4.SuspendLayout();
            this.panel_livre2.SuspendLayout();
            this.panel_livre3.SuspendLayout();
            this.panel_livre1.SuspendLayout();
            this.Membres_quantites.SuspendLayout();
            this.Auteurs_quantites.SuspendLayout();
            this.Livres_quantites.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.panel1.Controls.Add(this.bouton_membres);
            this.panel1.Controls.Add(this.bouton_usagers);
            this.panel1.Controls.Add(this.bouton_circulation);
            this.panel1.Controls.Add(this.bouton_genres);
            this.panel1.Controls.Add(this.bouton_auteurs);
            this.panel1.Controls.Add(this.bouton_livres);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(391, 789);
            this.panel1.TabIndex = 0;
            // 
            // bouton_membres
            // 
            this.bouton_membres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_membres.FlatAppearance.BorderSize = 0;
            this.bouton_membres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_membres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_membres.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_membres.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_membres.Location = new System.Drawing.Point(34, 646);
            this.bouton_membres.Name = "bouton_membres";
            this.bouton_membres.Size = new System.Drawing.Size(332, 83);
            this.bouton_membres.TabIndex = 8;
            this.bouton_membres.Text = "  MEMBRES";
            this.bouton_membres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_membres.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_membres.UseVisualStyleBackColor = true;
            this.bouton_membres.Click += new System.EventHandler(this.bouton_membres_Click);
            // 
            // bouton_usagers
            // 
            this.bouton_usagers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_usagers.FlatAppearance.BorderSize = 0;
            this.bouton_usagers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_usagers.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_usagers.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_usagers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_usagers.Location = new System.Drawing.Point(34, 557);
            this.bouton_usagers.Name = "bouton_usagers";
            this.bouton_usagers.Size = new System.Drawing.Size(332, 83);
            this.bouton_usagers.TabIndex = 7;
            this.bouton_usagers.Text = "  USAGERS";
            this.bouton_usagers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_usagers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_usagers.UseVisualStyleBackColor = true;
            // 
            // bouton_circulation
            // 
            this.bouton_circulation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_circulation.FlatAppearance.BorderSize = 0;
            this.bouton_circulation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_circulation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_circulation.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_circulation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_circulation.Location = new System.Drawing.Point(34, 468);
            this.bouton_circulation.Name = "bouton_circulation";
            this.bouton_circulation.Size = new System.Drawing.Size(332, 83);
            this.bouton_circulation.TabIndex = 6;
            this.bouton_circulation.Text = "  CIRCULATION";
            this.bouton_circulation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_circulation.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_circulation.UseVisualStyleBackColor = true;
            // 
            // bouton_genres
            // 
            this.bouton_genres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_genres.FlatAppearance.BorderSize = 0;
            this.bouton_genres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_genres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_genres.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_genres.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_genres.Location = new System.Drawing.Point(34, 379);
            this.bouton_genres.Name = "bouton_genres";
            this.bouton_genres.Size = new System.Drawing.Size(332, 83);
            this.bouton_genres.TabIndex = 5;
            this.bouton_genres.Text = "  GENRES";
            this.bouton_genres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_genres.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_genres.UseVisualStyleBackColor = true;
            this.bouton_genres.Click += new System.EventHandler(this.bouton_genres_Click);
            // 
            // bouton_auteurs
            // 
            this.bouton_auteurs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_auteurs.FlatAppearance.BorderSize = 0;
            this.bouton_auteurs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_auteurs.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_auteurs.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_auteurs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_auteurs.Location = new System.Drawing.Point(34, 290);
            this.bouton_auteurs.Name = "bouton_auteurs";
            this.bouton_auteurs.Size = new System.Drawing.Size(332, 83);
            this.bouton_auteurs.TabIndex = 4;
            this.bouton_auteurs.Text = "  AUTEURS";
            this.bouton_auteurs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_auteurs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_auteurs.UseVisualStyleBackColor = true;
            this.bouton_auteurs.Click += new System.EventHandler(this.bouton_auteurs_Click);
            // 
            // bouton_livres
            // 
            this.bouton_livres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bouton_livres.FlatAppearance.BorderSize = 0;
            this.bouton_livres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_livres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_livres.ForeColor = System.Drawing.Color.LightBlue;
            this.bouton_livres.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_livres.Location = new System.Drawing.Point(34, 201);
            this.bouton_livres.Name = "bouton_livres";
            this.bouton_livres.Size = new System.Drawing.Size(332, 83);
            this.bouton_livres.TabIndex = 3;
            this.bouton_livres.Text = "  LIVRES";
            this.bouton_livres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bouton_livres.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_livres.UseVisualStyleBackColor = true;
            this.bouton_livres.Click += new System.EventHandler(this.bouton_livres_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.Controls.Add(this.SGB_image);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(391, 170);
            this.panel2.TabIndex = 2;
            // 
            // SGB_image
            // 
            this.SGB_image.BackColor = System.Drawing.Color.LightBlue;
            this.SGB_image.Location = new System.Drawing.Point(17, 33);
            this.SGB_image.Name = "SGB_image";
            this.SGB_image.Size = new System.Drawing.Size(358, 100);
            this.SGB_image.TabIndex = 0;
            this.SGB_image.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(169, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Système Gestion Bibliothèque";
            // 
            // fond_tableau
            // 
            this.fond_tableau.BackColor = System.Drawing.Color.LightBlue;
            this.fond_tableau.Controls.Add(this.panel_dernier_livres);
            this.fond_tableau.Controls.Add(this.Membres_quantites);
            this.fond_tableau.Controls.Add(this.Auteurs_quantites);
            this.fond_tableau.Controls.Add(this.Livres_quantites);
            this.fond_tableau.Controls.Add(this.Fermer_bouton);
            this.fond_tableau.Location = new System.Drawing.Point(401, 10);
            this.fond_tableau.Name = "fond_tableau";
            this.fond_tableau.Size = new System.Drawing.Size(1069, 768);
            this.fond_tableau.TabIndex = 1;
            // 
            // panel_dernier_livres
            // 
            this.panel_dernier_livres.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel_dernier_livres.Controls.Add(this.panel_livre5);
            this.panel_dernier_livres.Controls.Add(this.panel_livre4);
            this.panel_dernier_livres.Controls.Add(this.panel_livre2);
            this.panel_dernier_livres.Controls.Add(this.panel_livre3);
            this.panel_dernier_livres.Controls.Add(this.panel_livre1);
            this.panel_dernier_livres.Controls.Add(this.Derniers_livres);
            this.panel_dernier_livres.Location = new System.Drawing.Point(11, 286);
            this.panel_dernier_livres.Name = "panel_dernier_livres";
            this.panel_dernier_livres.Size = new System.Drawing.Size(1049, 418);
            this.panel_dernier_livres.TabIndex = 3;
            // 
            // panel_livre5
            // 
            this.panel_livre5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_livre5.Controls.Add(this.label_pages_livre5);
            this.panel_livre5.Location = new System.Drawing.Point(834, 56);
            this.panel_livre5.Name = "panel_livre5";
            this.panel_livre5.Size = new System.Drawing.Size(200, 342);
            this.panel_livre5.TabIndex = 6;
            // 
            // label_pages_livre5
            // 
            this.label_pages_livre5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label_pages_livre5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pages_livre5.ForeColor = System.Drawing.Color.White;
            this.label_pages_livre5.Location = new System.Drawing.Point(44, 314);
            this.label_pages_livre5.Name = "label_pages_livre5";
            this.label_pages_livre5.Size = new System.Drawing.Size(114, 28);
            this.label_pages_livre5.TabIndex = 4;
            this.label_pages_livre5.Text = "999 pages";
            this.label_pages_livre5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_livre4
            // 
            this.panel_livre4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_livre4.Controls.Add(this.label_pages_livre4);
            this.panel_livre4.Location = new System.Drawing.Point(629, 56);
            this.panel_livre4.Name = "panel_livre4";
            this.panel_livre4.Size = new System.Drawing.Size(200, 342);
            this.panel_livre4.TabIndex = 5;
            // 
            // label_pages_livre4
            // 
            this.label_pages_livre4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label_pages_livre4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pages_livre4.ForeColor = System.Drawing.Color.White;
            this.label_pages_livre4.Location = new System.Drawing.Point(44, 314);
            this.label_pages_livre4.Name = "label_pages_livre4";
            this.label_pages_livre4.Size = new System.Drawing.Size(114, 28);
            this.label_pages_livre4.TabIndex = 3;
            this.label_pages_livre4.Text = "999 pages";
            this.label_pages_livre4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_livre2
            // 
            this.panel_livre2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_livre2.Controls.Add(this.label_pages_livre2);
            this.panel_livre2.Location = new System.Drawing.Point(424, 56);
            this.panel_livre2.Name = "panel_livre2";
            this.panel_livre2.Size = new System.Drawing.Size(200, 342);
            this.panel_livre2.TabIndex = 3;
            // 
            // label_pages_livre2
            // 
            this.label_pages_livre2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label_pages_livre2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pages_livre2.ForeColor = System.Drawing.Color.White;
            this.label_pages_livre2.Location = new System.Drawing.Point(44, 314);
            this.label_pages_livre2.Name = "label_pages_livre2";
            this.label_pages_livre2.Size = new System.Drawing.Size(114, 28);
            this.label_pages_livre2.TabIndex = 1;
            this.label_pages_livre2.Text = "999 pages";
            this.label_pages_livre2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_livre3
            // 
            this.panel_livre3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_livre3.Controls.Add(this.label_pages_livre3);
            this.panel_livre3.Location = new System.Drawing.Point(219, 56);
            this.panel_livre3.Name = "panel_livre3";
            this.panel_livre3.Size = new System.Drawing.Size(200, 342);
            this.panel_livre3.TabIndex = 4;
            // 
            // label_pages_livre3
            // 
            this.label_pages_livre3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label_pages_livre3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pages_livre3.ForeColor = System.Drawing.Color.White;
            this.label_pages_livre3.Location = new System.Drawing.Point(44, 314);
            this.label_pages_livre3.Name = "label_pages_livre3";
            this.label_pages_livre3.Size = new System.Drawing.Size(114, 28);
            this.label_pages_livre3.TabIndex = 2;
            this.label_pages_livre3.Text = "999 pages";
            this.label_pages_livre3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_livre1
            // 
            this.panel_livre1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_livre1.Controls.Add(this.label_pages_livre1);
            this.panel_livre1.Location = new System.Drawing.Point(14, 56);
            this.panel_livre1.Name = "panel_livre1";
            this.panel_livre1.Size = new System.Drawing.Size(200, 342);
            this.panel_livre1.TabIndex = 2;
            // 
            // label_pages_livre1
            // 
            this.label_pages_livre1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label_pages_livre1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pages_livre1.ForeColor = System.Drawing.Color.White;
            this.label_pages_livre1.Location = new System.Drawing.Point(44, 314);
            this.label_pages_livre1.Name = "label_pages_livre1";
            this.label_pages_livre1.Size = new System.Drawing.Size(114, 28);
            this.label_pages_livre1.TabIndex = 0;
            this.label_pages_livre1.Text = "999 pages";
            this.label_pages_livre1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Derniers_livres
            // 
            this.Derniers_livres.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Derniers_livres.Dock = System.Windows.Forms.DockStyle.Top;
            this.Derniers_livres.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Derniers_livres.ForeColor = System.Drawing.Color.LightBlue;
            this.Derniers_livres.Location = new System.Drawing.Point(0, 0);
            this.Derniers_livres.Name = "Derniers_livres";
            this.Derniers_livres.Size = new System.Drawing.Size(1049, 41);
            this.Derniers_livres.TabIndex = 1;
            this.Derniers_livres.Text = "DERNIERS LIVRES";
            this.Derniers_livres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Membres_quantites
            // 
            this.Membres_quantites.BackColor = System.Drawing.Color.MidnightBlue;
            this.Membres_quantites.Controls.Add(this.label_membres_qtes);
            this.Membres_quantites.Controls.Add(this.membres_label);
            this.Membres_quantites.Location = new System.Drawing.Point(713, 89);
            this.Membres_quantites.Name = "Membres_quantites";
            this.Membres_quantites.Size = new System.Drawing.Size(286, 134);
            this.Membres_quantites.TabIndex = 2;
            // 
            // label_membres_qtes
            // 
            this.label_membres_qtes.Font = new System.Drawing.Font("Arial Rounded MT Bold", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_membres_qtes.ForeColor = System.Drawing.Color.LightBlue;
            this.label_membres_qtes.Location = new System.Drawing.Point(3, 42);
            this.label_membres_qtes.Name = "label_membres_qtes";
            this.label_membres_qtes.Size = new System.Drawing.Size(280, 92);
            this.label_membres_qtes.TabIndex = 3;
            this.label_membres_qtes.Text = "999";
            this.label_membres_qtes.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // membres_label
            // 
            this.membres_label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(90)))));
            this.membres_label.Dock = System.Windows.Forms.DockStyle.Top;
            this.membres_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.membres_label.ForeColor = System.Drawing.Color.LightBlue;
            this.membres_label.Location = new System.Drawing.Point(0, 0);
            this.membres_label.Name = "membres_label";
            this.membres_label.Size = new System.Drawing.Size(286, 41);
            this.membres_label.TabIndex = 0;
            this.membres_label.Text = "MEMBRES";
            this.membres_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Auteurs_quantites
            // 
            this.Auteurs_quantites.BackColor = System.Drawing.Color.MidnightBlue;
            this.Auteurs_quantites.Controls.Add(this.label_auteurs_qtes);
            this.Auteurs_quantites.Controls.Add(this.Auteurs_label);
            this.Auteurs_quantites.Location = new System.Drawing.Point(389, 89);
            this.Auteurs_quantites.Name = "Auteurs_quantites";
            this.Auteurs_quantites.Size = new System.Drawing.Size(286, 134);
            this.Auteurs_quantites.TabIndex = 2;
            // 
            // label_auteurs_qtes
            // 
            this.label_auteurs_qtes.Font = new System.Drawing.Font("Arial Rounded MT Bold", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_auteurs_qtes.ForeColor = System.Drawing.Color.LightBlue;
            this.label_auteurs_qtes.Location = new System.Drawing.Point(4, 42);
            this.label_auteurs_qtes.Name = "label_auteurs_qtes";
            this.label_auteurs_qtes.Size = new System.Drawing.Size(279, 92);
            this.label_auteurs_qtes.TabIndex = 2;
            this.label_auteurs_qtes.Text = "999";
            this.label_auteurs_qtes.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Auteurs_label
            // 
            this.Auteurs_label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(90)))));
            this.Auteurs_label.Dock = System.Windows.Forms.DockStyle.Top;
            this.Auteurs_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Auteurs_label.ForeColor = System.Drawing.Color.LightBlue;
            this.Auteurs_label.Location = new System.Drawing.Point(0, 0);
            this.Auteurs_label.Name = "Auteurs_label";
            this.Auteurs_label.Size = new System.Drawing.Size(286, 41);
            this.Auteurs_label.TabIndex = 0;
            this.Auteurs_label.Text = "AUTEURS";
            this.Auteurs_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Livres_quantites
            // 
            this.Livres_quantites.BackColor = System.Drawing.Color.MidnightBlue;
            this.Livres_quantites.Controls.Add(this.label_livres_qtes);
            this.Livres_quantites.Controls.Add(this.livres_label);
            this.Livres_quantites.Location = new System.Drawing.Point(67, 89);
            this.Livres_quantites.Name = "Livres_quantites";
            this.Livres_quantites.Size = new System.Drawing.Size(286, 134);
            this.Livres_quantites.TabIndex = 1;
            // 
            // label_livres_qtes
            // 
            this.label_livres_qtes.Font = new System.Drawing.Font("Arial Rounded MT Bold", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_livres_qtes.ForeColor = System.Drawing.Color.LightBlue;
            this.label_livres_qtes.Location = new System.Drawing.Point(4, 42);
            this.label_livres_qtes.Name = "label_livres_qtes";
            this.label_livres_qtes.Size = new System.Drawing.Size(279, 92);
            this.label_livres_qtes.TabIndex = 1;
            this.label_livres_qtes.Text = "999";
            this.label_livres_qtes.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // livres_label
            // 
            this.livres_label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(90)))));
            this.livres_label.Dock = System.Windows.Forms.DockStyle.Top;
            this.livres_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.livres_label.ForeColor = System.Drawing.Color.LightBlue;
            this.livres_label.Location = new System.Drawing.Point(0, 0);
            this.livres_label.Name = "livres_label";
            this.livres_label.Size = new System.Drawing.Size(286, 41);
            this.livres_label.TabIndex = 0;
            this.livres_label.Text = "LIVRES";
            this.livres_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Fermer_bouton
            // 
            this.Fermer_bouton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Fermer_bouton.FlatAppearance.BorderSize = 0;
            this.Fermer_bouton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Fermer_bouton.Location = new System.Drawing.Point(1006, 5);
            this.Fermer_bouton.Name = "Fermer_bouton";
            this.Fermer_bouton.Size = new System.Drawing.Size(48, 48);
            this.Fermer_bouton.TabIndex = 0;
            this.Fermer_bouton.UseVisualStyleBackColor = true;
            this.Fermer_bouton.Click += new System.EventHandler(this.Fermer_bouton_Click);
            // 
            // tableau_de_bord_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1478, 789);
            this.Controls.Add(this.fond_tableau);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "tableau_de_bord_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "tableau_de_bord_formulaire";
            this.Load += new System.EventHandler(this.tableau_de_bord_formulaire_Load);
            this.Shown += new System.EventHandler(this.tableau_de_bord_formulaire_Shown);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SGB_image)).EndInit();
            this.fond_tableau.ResumeLayout(false);
            this.panel_dernier_livres.ResumeLayout(false);
            this.panel_livre5.ResumeLayout(false);
            this.panel_livre4.ResumeLayout(false);
            this.panel_livre2.ResumeLayout(false);
            this.panel_livre3.ResumeLayout(false);
            this.panel_livre1.ResumeLayout(false);
            this.Membres_quantites.ResumeLayout(false);
            this.Auteurs_quantites.ResumeLayout(false);
            this.Livres_quantites.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox SGB_image;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel fond_tableau;
        private System.Windows.Forms.Button Fermer_bouton;
        private System.Windows.Forms.Panel Membres_quantites;
        private System.Windows.Forms.Panel Auteurs_quantites;
        private System.Windows.Forms.Panel Livres_quantites;
        private System.Windows.Forms.Panel panel_dernier_livres;
        private System.Windows.Forms.Label membres_label;
        private System.Windows.Forms.Label Auteurs_label;
        private System.Windows.Forms.Label livres_label;
        private System.Windows.Forms.Label label_membres_qtes;
        private System.Windows.Forms.Label label_auteurs_qtes;
        private System.Windows.Forms.Label label_livres_qtes;
        private System.Windows.Forms.Label Derniers_livres;
        private System.Windows.Forms.Panel panel_livre2;
        private System.Windows.Forms.Panel panel_livre1;
        private System.Windows.Forms.Panel panel_livre5;
        private System.Windows.Forms.Panel panel_livre4;
        private System.Windows.Forms.Panel panel_livre3;
        private System.Windows.Forms.Label label_pages_livre5;
        private System.Windows.Forms.Label label_pages_livre4;
        private System.Windows.Forms.Label label_pages_livre2;
        private System.Windows.Forms.Label label_pages_livre3;
        private System.Windows.Forms.Label label_pages_livre1;
        private System.Windows.Forms.Button bouton_livres;
        private System.Windows.Forms.Button bouton_membres;
        private System.Windows.Forms.Button bouton_usagers;
        private System.Windows.Forms.Button bouton_circulation;
        private System.Windows.Forms.Button bouton_genres;
        private System.Windows.Forms.Button bouton_auteurs;
    }
}