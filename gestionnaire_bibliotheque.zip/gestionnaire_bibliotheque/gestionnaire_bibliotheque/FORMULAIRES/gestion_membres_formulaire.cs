﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class gestion_membres_formulaire : Form
    {
        public gestion_membres_formulaire()
        {
            InitializeComponent();
        }

        CLASSES.MEMBRE membre = new CLASSES.MEMBRE();

        //quand on ouvre le formulaire
        private void gestion_membres_formulaire_Load(object sender, EventArgs e)
        {
            //Images boutons
            bouton_ajouter.Image = Image.FromFile("../../IMAGES/plus.png");
            bouton_modifier.Image = Image.FromFile("../../IMAGES/updates.png");
            bouton_supprimer.Image = Image.FromFile("../../IMAGES/delete.png");
            bouton_teledeposer_photo.Image = Image.FromFile("../../IMAGES/telecharge.png");
            bouton_effacer_champs.Image = Image.FromFile("../../IMAGES/clear.png");

            //modifier les rangées  de datagridview la hauteur
            dataGridView_membre.RowTemplate.Height = 100;

            /* montrer le tableau de la liste des membres 
             * (false = prenom et nom *** vrai = par concaténation nom complet au lieu de prenom et nom*/
            dataGridView_membre.DataSource = membre.listeMembres(false);

            // Modifier la grille (header)
            dataGridView_membre.ColumnHeadersDefaultCellStyle.ForeColor = Color.MidnightBlue;
            dataGridView_membre.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 16, FontStyle.Bold);
            dataGridView_membre.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridView_membre.EnableHeadersVisualStyles = false;

            //modifier les rangées  de datagridview la pochette
            DataGridViewImageColumn dgvImgCol = new DataGridViewImageColumn();
            dgvImgCol = (DataGridViewImageColumn)dataGridView_membre.Columns[6];
            dgvImgCol.ImageLayout = DataGridViewImageCellLayout.Stretch;

            //afficher le compteur de membres
            label_compteur_membres.Text = membre.listeMembres(false).Rows.Count.ToString() + " membres";

            dataGridView_membre.EnableHeadersVisualStyles = false;
        }
        //Bouton pour fermer le formulaire
        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Bouton pour télédéposer l'image du membre
        private void bouton_teledeposer_photo_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            //types d'image
            opf.Filter = "Choisissez une image(*.jpg;*.png;*.gif)| *.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                //Placer l'image dans la boite_image
                pictureBox_photo_membre.Image = Image.FromFile(opf.FileName);
            }
        }
        //Bouton radio femme
        private void radioButton_femme_CheckedChanged(object sender, EventArgs e)
        {
            radioButton_femme.ForeColor = Color.MidnightBlue;
            radioButton_homme.ForeColor = Color.Black;
            radioButton_femme.Font = new Font(radioButton_femme.Font, FontStyle.Bold);
            radioButton_homme.Font = new Font(radioButton_homme.Font, FontStyle.Regular);
        }
        //bouton radio homme
        private void radioButton_homme_CheckedChanged(object sender, EventArgs e)
        {
            radioButton_homme.ForeColor = Color.MidnightBlue;
            radioButton_femme.ForeColor = Color.Black;
            radioButton_femme.Font = new Font(radioButton_femme.Font, FontStyle.Regular);
            radioButton_homme.Font = new Font(radioButton_homme.Font, FontStyle.Bold);
        }
       
        //-----------------------------------------------------------------------------
        //  ***********     BOUTON MANIPULATION DES DONNÉES     ***********************
        //-----------------------------------------------------------------------------
        
            //Bouton ajouter un membre
        private void bouton_ajouter_Click(object sender, EventArgs e)
        {
            string prenom = texte_prenom.Text;
            string nom = texte_nom.Text;
            string cellulaire = texte_cellulaire.Text;
            string courriel = texte_courriel.Text;
            string sexe = "Femme"; //par défaut

            if(radioButton_homme.Checked)
            {
                sexe = "Homme";
            }

            MemoryStream ms = new MemoryStream();
            pictureBox_photo_membre.Image.Save(ms, pictureBox_photo_membre.Image.RawFormat);
            byte[] photo = ms.ToArray();

            // vérifie si le prénom/nom/cellulaire/courriel sont vide
            if (prenom.Trim().Equals("") || nom.Trim().Equals("") || cellulaire.Trim().Equals("") || courriel.Trim().Equals(""))
            {
                MessageBox.Show("Vous devez remplir tous les champs avec un * rouge afin de valider le membre", "Data vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (membre.ajouterMembre(prenom, nom, sexe, cellulaire, courriel, photo))
                {

                    MessageBox.Show("Nouveau membre ajouté avec succès", "Nouveau membre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // mise à jour du tableau des membres
                        dataGridView_membre.DataSource = membre.listeMembres(true);

                    //mise à jour du compteur de membres
                        label_compteur_membres.Text = membre.listeMembres(true).Rows.Count.ToString() + " membres";
                   
                }
                else
                {
                    MessageBox.Show("Pas de Nouveau membre ajouté", "Nouveau membre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
        }

            //Bouton Modifier un membre sélectionné
        private void bouton_modifier_Click(object sender, EventArgs e)
        {
            int id ;
            string prenom = texte_prenom.Text;
            string nom = texte_nom.Text;
            string cellulaire = texte_cellulaire.Text;
            string courriel = texte_courriel.Text;
            string sexe = "Femme"; //par défaut

            if (radioButton_homme.Checked)
            {
                sexe = "Homme";
            }

            MemoryStream ms = new MemoryStream();
            pictureBox_photo_membre.Image.Save(ms, pictureBox_photo_membre.Image.RawFormat);
            byte[] photo = ms.ToArray();

            //id est vide? ou non?
            if (!texte_id.Text.Equals(""))
            {
                id = Convert.ToInt32(texte_id.Text);
                // vérifie si le prénom/nom/cellulaire/courriel sont vide
                if (prenom.Trim().Equals("") || nom.Trim().Equals("") || cellulaire.Trim().Equals("") || courriel.Trim().Equals(""))
                {
                    MessageBox.Show("Vous devez remplir tous les champs avec un * rouge afin de valider le membre", "Data vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (membre.modifierMembre(id, prenom, nom, sexe, cellulaire, courriel, photo))
                    {

                        MessageBox.Show("Membre modifié avec succès", "Modification de membre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // mise à jour du tableau des membres
                        dataGridView_membre.DataSource = membre.listeMembres(true);

                        //mise à jour du compteur de membres
                        label_compteur_membres.Text = membre.listeMembres(true).Rows.Count.ToString() + " membres";

                    }
                    else
                    {
                        MessageBox.Show("Le membre n'a pas été modifier", "Modificaton du membre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("Sélectionnez un membre dans la liste en premier", "Sélection de membre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        //sélection d'une rangée pour exporter dans formulaire
        private void dataGridView_membre_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            texte_id.Text = dataGridView_membre.CurrentRow.Cells[0].Value.ToString();
            texte_prenom.Text = dataGridView_membre.CurrentRow.Cells[1].Value.ToString();
            texte_nom.Text = dataGridView_membre.CurrentRow.Cells[2].Value.ToString();
            /* ---- si j'utilise la concaténation ----- effacer les 2 lignes du dessus et changer les []
            string nomcomplet = dataGridView_membre.CurrentRow[1].Value.Tostring();
            var prenome_et_nom = nomcomplet.split(' - ');
            texte_prenom.Text = prenom_et_nom[0];
            texte_nom.Text = prenom_et_nom[1];
            */
            string sexe = dataGridView_membre.CurrentRow.Cells[3].Value.ToString();
            if (sexe.Equals("Femme"))
            {
                radioButton_femme.Checked = true;
            }
            else
            {
                radioButton_homme.Checked = true;
            }
            texte_cellulaire.Text = dataGridView_membre.CurrentRow.Cells[4].Value.ToString();
            texte_courriel.Text = dataGridView_membre.CurrentRow.Cells[5].Value.ToString();

            byte[] photo = (byte[])dataGridView_membre.CurrentRow.Cells[6].Value;
            MemoryStream ms = new MemoryStream(photo);
            pictureBox_photo_membre.Image = Image.FromStream(ms);

        }


        //Bouton Supprimer un membre sélectioné
        private void bouton_supprimer_Click(object sender, EventArgs e)
        {
            int id;
            if(!texte_id.Text.Trim().Equals(""))
            {
                id = Convert.ToInt32(texte_id.Text);

                //Demander une confirmation avant de supprimer
                if (MessageBox.Show("Voulez-vous vraiment supprimer le membre?", "Confirmation de Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (membre.supprimerMembre(id))
                    {
                        MessageBox.Show("Membre supprimé avec succès", "Suppression de membre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // mise à jour du tableau des membres
                        dataGridView_membre.DataSource = membre.listeMembres(true);

                        //mise à jour du compteur de membres
                        label_compteur_membres.Text = membre.listeMembres(true).Rows.Count.ToString() + " membres";

                        //rappel du bouton pour effacer les champs
                        bouton_effacer_champs.PerformClick();
                    }
                    else
                    {
                        MessageBox.Show("Le membre n'a pas été supprimer", "Suppression du membre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }       
            }
            else
            {
                MessageBox.Show("Il faut sélectionner un membre avant", "Sélection du membre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        //Effacer tous les champs
        private void bouton_effacer_champs_Click(object sender, EventArgs e)
        {
            texte_id.Text = "";
            texte_prenom.Text = "";
            texte_nom.Text = "";
            radioButton_femme.Checked = true;
            texte_cellulaire.Text = "";
            texte_courriel.Text = "";
            pictureBox_photo_membre.ImageLocation = "../../IMAGES/membre_template.png";
        }
    }
}
