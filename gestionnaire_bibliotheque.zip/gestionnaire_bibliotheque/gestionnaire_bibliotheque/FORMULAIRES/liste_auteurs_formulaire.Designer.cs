﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class liste_auteurs_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.listBox_auteurs = new System.Windows.Forms.ListBox();
            this.bouton_selection_fermer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 75);
            this.label1.TabIndex = 1;
            this.label1.Text = "Liste des auteurs";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(344, 2);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 2;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // listBox_auteurs
            // 
            this.listBox_auteurs.FormattingEnabled = true;
            this.listBox_auteurs.Location = new System.Drawing.Point(4, 80);
            this.listBox_auteurs.Name = "listBox_auteurs";
            this.listBox_auteurs.Size = new System.Drawing.Size(367, 342);
            this.listBox_auteurs.TabIndex = 3;
            this.listBox_auteurs.SelectedIndexChanged += new System.EventHandler(this.listBox_auteurs_SelectedIndexChanged);
            // 
            // bouton_selection_fermer
            // 
            this.bouton_selection_fermer.BackColor = System.Drawing.Color.LightBlue;
            this.bouton_selection_fermer.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.bouton_selection_fermer.FlatAppearance.BorderSize = 2;
            this.bouton_selection_fermer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bouton_selection_fermer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bouton_selection_fermer.ForeColor = System.Drawing.Color.DarkGreen;
            this.bouton_selection_fermer.Location = new System.Drawing.Point(21, 442);
            this.bouton_selection_fermer.Name = "bouton_selection_fermer";
            this.bouton_selection_fermer.Size = new System.Drawing.Size(333, 41);
            this.bouton_selection_fermer.TabIndex = 10;
            this.bouton_selection_fermer.Text = "Sélectionner et fermer";
            this.bouton_selection_fermer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bouton_selection_fermer.UseVisualStyleBackColor = false;
            this.bouton_selection_fermer.Click += new System.EventHandler(this.bouton_selection_fermer_Click);
            // 
            // liste_auteurs_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(379, 505);
            this.Controls.Add(this.bouton_selection_fermer);
            this.Controls.Add(this.listBox_auteurs);
            this.Controls.Add(this.Label_fermeture);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "liste_auteurs_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "liste_auteurs_formulaire";
            this.Load += new System.EventHandler(this.liste_auteurs_formulaire_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.ListBox listBox_auteurs;
        private System.Windows.Forms.Button bouton_selection_fermer;
    }
}