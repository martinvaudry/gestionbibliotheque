﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class tableau_de_bord_formulaire : Form
    {
        public tableau_de_bord_formulaire()
        {
            InitializeComponent();
        }
        //ce qui est montrer quand on lance le formulaire
        private void tableau_de_bord_formulaire_Load(object sender, EventArgs e)
        {

            // logo du gestionnaire
            SGB_image.Image = Image.FromFile("../../IMAGES/SGB_logo.png");

            // image d'icone de fermeture d'application
            Fermer_bouton.Image = Image.FromFile("../../IMAGES/Fermer.png");

            //icones bouton du dashboard
            bouton_livres.Image = Image.FromFile("../../IMAGES/bouton_livres.png");
            bouton_auteurs.Image = Image.FromFile("../../IMAGES/bouton_auteurs.png");
            bouton_genres.Image = Image.FromFile("../../IMAGES/bouton_genres.png");
            bouton_circulation.Image = Image.FromFile("../../IMAGES/bouton_circulation.png");
            bouton_usagers.Image = Image.FromFile("../../IMAGES/bouton_usagers.png");
            bouton_membres.Image = Image.FromFile("../../IMAGES/bouton_membres.png");

            // Afficher les pochettes et leurs nombres de pages aux 5 derniers livres ajoutés
            DataTable livreData = livre.listelivres();

            //loop pour placer les derniers livres
            byte[] img;
            MemoryStream ms;
            int i = 0; //index pour la table rows

            foreach (var panelControl in panel_dernier_livres.Controls)
            {
                if (panelControl.GetType() == typeof(Panel))
                {
                    //montrer l'image du livre
                    Panel panel = (Panel)panelControl;
                    img = (byte[])livreData.Rows[i][11];
                    ms = new MemoryStream(img);
                    panel.BackgroundImage = Image.FromStream(ms);
                    panel.BackgroundImageLayout = ImageLayout.Stretch;

                    //montrer le nombre de page du livre
                    foreach (var labelControl in panel.Controls)
                    {
                        if (labelControl.GetType() == typeof(Label))
                        {
                            Label label = (Label)labelControl;
                            label.Text = livreData.Rows[i][5].ToString() + " pages";
                        }
                    }
                    i++;
                }
            }

        }

        CLASSES.AUTEUR AUTEUR = new CLASSES.AUTEUR();
        CLASSES.LIVRES livre = new CLASSES.LIVRES();
        CLASSES.MEMBRE membre = new CLASSES.MEMBRE();

        private void Fermer_bouton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tableau_de_bord_formulaire_Shown(object sender, EventArgs e)
        {
            //Empêche l'Accès au tableau de bord avant la connexion
            this.Enabled = false;
            //Montrer le formulaire de connexion
            Connexion_formlaire lgf = new Connexion_formlaire(this);
            lgf.Show();

            //afficher le compteur de livres / auteurs / membres
                                     //compteur de livre
            label_livres_qtes.Text = livre.listelivres().Rows.Count.ToString() + " Livres";
                                     //compteur de auteurs
            label_auteurs_qtes.Text = AUTEUR.listeauteurs(false).Rows.Count.ToString() + " auteurs";
                                    //compteur de membres
            label_membres_qtes.Text = membre.listeMembres(false).Rows.Count.ToString() + " membres";
        }
        //Montrer le formulaire de gestion des genres
        private void bouton_genres_Click(object sender, EventArgs e)
        {
            gestion_genres_formulaire gesgenf = new gestion_genres_formulaire();
            gesgenf.Show();
        }
        //Montrer le formulaire de gestion des auteurs
        private void bouton_auteurs_Click(object sender, EventArgs e)
        {
            gestion_auteurs_formulaire gesauteursf = new gestion_auteurs_formulaire();
            gesauteursf.Show();
        }
        //Montrer le formulaire de gestion des livres
        private void bouton_livres_Click(object sender, EventArgs e)
        {
            gestion_livres_formulaire geslivresf = new gestion_livres_formulaire();
            geslivresf.Show();
        }
        //Montrer le gestionnaire des membres
        private void bouton_membres_Click(object sender, EventArgs e)
        {
            gestion_membres_formulaire gesmembresf = new gestion_membres_formulaire();
            gesmembresf.Show();
        }
        // ----------------------------------------------------------------------------------------------------

    }
}
