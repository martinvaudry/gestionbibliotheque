﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestionnaire_bibliotheque.FORMULAIRES
{
    public partial class gestion_genres_formulaire : Form
    {

        public gestion_genres_formulaire()
        {
            InitializeComponent();
        }

        CLASSES.GENRES genres = new CLASSES.GENRES();

       
        private void gestion_genres_formulaire_Load(object sender, EventArgs e)
        {
            //Images boutons
            bouton_ajouter.Image = Image.FromFile("../../IMAGES/plus.png");
            bouton_modifier.Image = Image.FromFile("../../IMAGES/updates.png");
            bouton_supprimer.Image = Image.FromFile("../../IMAGES/delete.png");

            // montrer le tableau des genres
            dataGridView_genre.DataSource = genres.listegenres();

            // Modifier la grille 
            dataGridView_genre.ColumnHeadersDefaultCellStyle.ForeColor = Color.MidnightBlue;
            dataGridView_genre.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            dataGridView_genre.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView_genre.EnableHeadersVisualStyles = false;
        }
        //----------------------------------------------------------------------------
        //                      FERMER LE TABLEAU GENRES
        //-----------------------------------------------------------------------------
        private void Label_fermeture_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //------------------------------------------------------------------------------
        //                           BOUTON AJOUT
        //------------------------------------------------------------------------------
        private void bouton_ajout_Click(object sender, EventArgs e)
        {
           
            string nom = texte_nom.Text;

            if (nom.Trim().Equals(""))
            {
                MessageBox.Show("Entrez un nom de genre", "Nom de genre vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if(genres.ajoutgenre(nom))
                {
                    MessageBox.Show("Nouveau genre ajouté avec succès", "Nouveau genre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // mise à jour du tableau des genres
                    dataGridView_genre.DataSource = genres.listegenres();
                }
                else
                {
                    MessageBox.Show("Pas de nouveau genre ajouté", "Nouveau genre en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------
        //                           BOUTON MODIFIER
        //------------------------------------------------------------------------------------------------------------------------------------------
        private void bouton_modifier_Click(object sender, EventArgs e)
        {

            try
            {
                int id = Convert.ToInt32(texte_id.Text);
                string nom = texte_nom.Text;

                if (nom.Trim().Equals(""))
                {
                    MessageBox.Show("Entrez un nom de genre", "Nom de genre vide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (genres.modifiergenre(id, nom))
                    {
                        MessageBox.Show("Nouveau genre modifié avec succès", "Modification du nom de genre", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // mise à jour du tableau des genres
                        dataGridView_genre.DataSource = genres.listegenres();
                    }
                    else
                    {
                        MessageBox.Show("Le nom de genre n'a pas été modifier", "la modification de genre est en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"L'id est invalide");
            }

        }
        //------------------------------------------------------------------------------------------------------------------------------------------
        //                           BOUTON SUPPRIMER
        //------------------------------------------------------------------------------------------------------------------------------------------
        private void bouton_supprimer_Click(object sender, EventArgs e)
        {

            try
            {
                int id = Convert.ToInt32(texte_id.Text);

                //Demander une confirmation avant de supprimer
                if (MessageBox.Show("Voulez-vous vraiment supprimer ce genre)?", "Confirmation de Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    if (genres.supprimergenre(id))
                    {
                        MessageBox.Show("Le genre à été supprimé avec succès", "Supprimer un nom de genre", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // nettoyer les champs
                        texte_id.Text = "";
                        texte_nom.Text = "";
                        // mise à jour du tableau des genres
                        dataGridView_genre.DataSource = genres.listegenres();
                    }
                    else
                    {
                        MessageBox.Show("Le nom de genre n'a pas été supprimer", "La suppression de genre est en erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "L'id est invalide");
            }

        }
        //------------------------------------------------------------------------------------------------------------------------------------------
        //                           GRILLE DES GENRES / montrer le genre qui est sélectionné
        //------------------------------------------------------------------------------------------------------------------------------------------
        private void dataGridView_genre_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            texte_id.Text = dataGridView_genre.CurrentRow.Cells[0].Value.ToString();
            texte_nom.Text = dataGridView_genre.CurrentRow.Cells[1].Value.ToString();
        }
    }
}
