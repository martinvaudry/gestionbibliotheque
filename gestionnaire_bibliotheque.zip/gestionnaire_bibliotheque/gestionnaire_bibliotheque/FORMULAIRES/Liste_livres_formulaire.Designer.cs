﻿namespace gestionnaire_bibliotheque.FORMULAIRES
{
    partial class Liste_livres_formulaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_liste_auteur = new System.Windows.Forms.Label();
            this.Label_fermeture = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList_pochette_livre = new System.Windows.Forms.ImageList(this.components);
            this.listView_listeDeLivres = new System.Windows.Forms.ListView();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.Controls.Add(this.listView_listeDeLivres);
            this.panel1.Controls.Add(this.label_liste_auteur);
            this.panel1.Controls.Add(this.Label_fermeture);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(581, 685);
            this.panel1.TabIndex = 1;
            // 
            // label_liste_auteur
            // 
            this.label_liste_auteur.AutoSize = true;
            this.label_liste_auteur.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_liste_auteur.ForeColor = System.Drawing.Color.LightBlue;
            this.label_liste_auteur.Location = new System.Drawing.Point(113, 82);
            this.label_liste_auteur.Name = "label_liste_auteur";
            this.label_liste_auteur.Size = new System.Drawing.Size(342, 24);
            this.label_liste_auteur.TabIndex = 3;
            this.label_liste_auteur.Text = "livres écrit par:  PRENOMETNOM";
            // 
            // Label_fermeture
            // 
            this.Label_fermeture.AutoSize = true;
            this.Label_fermeture.BackColor = System.Drawing.Color.LightBlue;
            this.Label_fermeture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_fermeture.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fermeture.ForeColor = System.Drawing.Color.Red;
            this.Label_fermeture.Location = new System.Drawing.Point(545, 3);
            this.Label_fermeture.Name = "Label_fermeture";
            this.Label_fermeture.Size = new System.Drawing.Size(33, 31);
            this.Label_fermeture.TabIndex = 1;
            this.Label_fermeture.Text = "X";
            this.Label_fermeture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_fermeture.Click += new System.EventHandler(this.Label_fermeture_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(580, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "Liste de livres par auteur";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imageList_pochette_livre
            // 
            this.imageList_pochette_livre.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList_pochette_livre.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList_pochette_livre.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listView_listeDeLivres
            // 
            this.listView_listeDeLivres.BackColor = System.Drawing.Color.LightBlue;
            this.listView_listeDeLivres.ForeColor = System.Drawing.Color.MidnightBlue;
            this.listView_listeDeLivres.HideSelection = false;
            this.listView_listeDeLivres.Location = new System.Drawing.Point(9, 114);
            this.listView_listeDeLivres.Name = "listView_listeDeLivres";
            this.listView_listeDeLivres.Size = new System.Drawing.Size(563, 560);
            this.listView_listeDeLivres.TabIndex = 4;
            this.listView_listeDeLivres.UseCompatibleStateImageBehavior = false;
            // 
            // Liste_livres_formulaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 685);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Liste_livres_formulaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Liste_livres_formulaire";
            this.Load += new System.EventHandler(this.Liste_livres_formulaire_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Label_fermeture;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_liste_auteur;
        private System.Windows.Forms.ImageList imageList_pochette_livre;
        private System.Windows.Forms.ListView listView_listeDeLivres;
    }
}