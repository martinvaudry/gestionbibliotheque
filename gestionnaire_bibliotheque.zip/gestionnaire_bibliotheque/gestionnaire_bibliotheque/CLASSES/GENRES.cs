﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace gestionnaire_bibliotheque.CLASSES
{
    class GENRES
    {

        LA_BASE_DE_DONNEE.SGB_basededonnee db = new LA_BASE_DE_DONNEE.SGB_basededonnee();

        //création d'une fonction pour ajouter un genre
        public Boolean ajoutgenre(string nom)
        {
            string query = "INSERT INTO `genres`(`nom`) VALUES (@genres_nom)";

            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("@genres_nom", MySqlDbType.VarChar);
            parameters[0].Value = nom;

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
            

        }

        //création d'une fonction pour modifier un genre
        public Boolean modifiergenre(int id, string nom)
        {
            string query = "UPDATE `genres` SET `nom` = @genre_nom WHERE `id` = @id";

            MySqlParameter[] parameters = new MySqlParameter[2];
            parameters[0] = new MySqlParameter("@genres_nom", MySqlDbType.VarChar);
            parameters[0].Value = nom;

            parameters[1] = new MySqlParameter("@id", MySqlDbType.Int32);
            parameters[1].Value = id;

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //création d'une fonction pour supprimer un genre
        public Boolean supprimergenre(int id)
        {
            string query = "DELETE FROM `genres` WHERE `id` = @id";

            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("@id", MySqlDbType.Int32);
            parameters[0].Value = id;

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //crétation d'une fonction pour retourner au tableau des genres
        public DataTable listegenres()
        {
            DataTable table = new DataTable();
            table = db.GetData("SELECT * FROM `genres`", null);
            return table;
        }

    }
}
