﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace gestionnaire_bibliotheque.CLASSES
{
    class MEMBRE
    {

        LA_BASE_DE_DONNEE.SGB_basededonnee db = new LA_BASE_DE_DONNEE.SGB_basededonnee();

        //Créer une foncton pour ajouter un membre
        public Boolean ajouterMembre(string prenom, string nom, string sexe, string cellulaire, string courriel, byte[] photo)
        {
            string query = "INSERT INTO `membre`(`prenom`, `nom`, `sexe`, `cellulaire`, `courriel`, `photo`) VALUES (@membre_prenom, @membre_nom, @membre_sexe, @membre_cellulaire, @membre_courriel, @membre_photo)";

            MySqlParameter[] parameters = new MySqlParameter[6];
            //------------------------------------------------
            parameters[0] = new MySqlParameter("@membre_prenom", MySqlDbType.VarChar);
            parameters[0].Value = prenom;
            //------------------------------------------------
            parameters[1] = new MySqlParameter("@membre_nom", MySqlDbType.VarChar);
            parameters[1].Value = nom;
            //------------------------------------------------
            parameters[2] = new MySqlParameter("@membre_sexe", MySqlDbType.VarChar);
            parameters[2].Value = sexe;
            //------------------------------------------------
            parameters[3] = new MySqlParameter("@membre_cellulaire", MySqlDbType.VarChar);
            parameters[3].Value = cellulaire;
            //------------------------------------------------
            parameters[4] = new MySqlParameter("@membre_courriel", MySqlDbType.VarChar);
            parameters[4].Value = courriel;
            //------------------------------------------------
            parameters[5] = new MySqlParameter("@membre_photo", MySqlDbType.Blob);
            parameters[5].Value = photo;
            //------------------------------------------------

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Créer une foncton pour modifier un membre
        public Boolean modifierMembre(int id,string prenom, string nom, string sexe, string cellulaire, string courriel, byte[] photo)
        {
            string query = "UPDATE `membre` SET  `prenom`=@membre_prenom, `nom`=@membre_nom, `sexe`=@membre_sexe, `cellulaire`=@membre_cellulaire, `courriel`=@membre_courriel, `photo`=@membre_photo WHERE `id`=@membre_id";

            MySqlParameter[] parameters = new MySqlParameter[7];
            //------------------------------------------------
            parameters[0] = new MySqlParameter("@membre_prenom", MySqlDbType.VarChar);
            parameters[0].Value = prenom;
            //------------------------------------------------
            parameters[1] = new MySqlParameter("@membre_nom", MySqlDbType.VarChar);
            parameters[1].Value = nom;
            //------------------------------------------------
            parameters[2] = new MySqlParameter("@membre_sexe", MySqlDbType.VarChar);
            parameters[2].Value = sexe;
            //------------------------------------------------
            parameters[3] = new MySqlParameter("@membre_cellulaire", MySqlDbType.VarChar);
            parameters[3].Value = cellulaire;
            //------------------------------------------------
            parameters[4] = new MySqlParameter("@membre_courriel", MySqlDbType.VarChar);
            parameters[4].Value = courriel;
            //------------------------------------------------
            parameters[5] = new MySqlParameter("@membre_photo", MySqlDbType.Blob);
            parameters[5].Value = photo;
            //------------------------------------------------
            parameters[6] = new MySqlParameter("@membre_id", MySqlDbType.Int32);
            parameters[6].Value = id;
            //------------------------------------------------

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //création d'une fonction pour supprimer un membre
        public Boolean supprimerMembre(int id)
        {
            string query = "DELETE FROM `membre` WHERE `id` = @id";

            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("@id", MySqlDbType.Int32);
            parameters[0].Value = id;

            if (db.setData(query, parameters) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //crétation d'une fonction pour retourner au tableau des genres
        public DataTable listeMembres(Boolean display_nomcomplet)
        {
            string query = "SELECT * FROM `membre`";

            if (display_nomcomplet)
            {
                query = "SELECT `id`, Concat(`prenom`, ' ', `nom`) as nomcomplet, `sexe`, `cellulaire`, `courriel`, `photo` FROM `membre`";
            }
            DataTable table = new DataTable();
            table = db.GetData(query, null);
            return table;
        }
    }
}
